﻿using dek_erpvis_v2.cls;
using Support;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace dek_erpvis_v2.pages.dp_PM
{
    public partial class Asm_ELine : System.Web.UI.Page
    {
        public string th_Time = ""; //時程表 欄位
        public string tr_Time = ""; //時程表 內容
        public string th_Dispatch = "";  //派工單 欄位
        public string tr_Dispatch = "";//派工單 內容
        public string th_Report = "";//報工單 欄位
        public string tr_Report = "";//報工單 內容
        public string th_Performance = "";//績效表 欄位
        public string tr_Performance = "";//績效表 內容
        public string color = "";//顏色修改相關
        public string class_name = "col-md-9 col-sm-12 col-xs-12";
        public List<string> html_code = new List<string>();
        int count = 0;
        string acc = "";
        string URL_NAME = "";
        myclass myclass = new myclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                color = HtmlUtil.change_color(acc);

                URL_NAME = "Asm_ELine";
                if (myclass.user_view_check(URL_NAME, acc) == true || true)
                {
                    if (!IsPostBack)
                        load_data();
                }
                else
                    Response.Write("<script>alert('您無法瀏覽此頁面 請向該單位主管申請權限!');location.href='../index.aspx';</script>");
            }
            else
                Response.Redirect(myclass.logout_url);
        }
        //存入資料庫
        protected void Button_submit_Click(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
            string sqlcmd = "";
            DataTable dt = new DataTable();
            DataTable dr = new DataTable();
            int dt_count = 1;
            //派工
            if (DataTableUtils.toString(((Control)sender).ID.Split('_')[1]) == "Dispatch")
            {
                //只能派今天之後的，不能派今天之前的
                sqlcmd = $"select * from DataSource where  ProductID = '{TextBox_Product.Text}' and (Dispatch_staff is null OR Dispatch_staff = '' ) and CAST ( DeliveryTime AS INT ) >={DateTime.Now.ToString("yyyyMMdd")} order by ID asc ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                {
                    for (int i = 0; i < DataTableUtils.toInt(TextBox_DispatchCount.Text); i++)
                    {
                        DataRow row = dt.NewRow();
                        row["ID"] = DataTableUtils.toString(dt.Rows[i]["ID"]);
                        row["Dispatch_staff"] = RadioButtonList_Man.SelectedItem.Text;
                        row["Dispatch_Date"] = TextBox_Dispatch.Text.Replace("-", "");
                        row["Assignor"] = HtmlUtil.Search_acc_Column(acc, "USER_NAME");
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                        DataTableUtils.Update_DataRow("DataSource", $"ID={DataTableUtils.toString(dt.Rows[i]["ID"])}", row);
                    }
                }
                html_code.Clear();
                //報工
                html_code.Add("");
                html_code.Add("false");
                html_code.Add("");
                //派工
                html_code.Add("active");
                html_code.Add("true");
                html_code.Add("active in");

            }
            //報工
            else
            {
                sqlcmd = $"select * from DataSource where ProductID = '{TextBox_ID.Text}' and FinishTime is null order by ID asc ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                {
                    for (int i = 0; i < DataTableUtils.toInt(TextBox_count.Text); i++)
                    {
                        DataRow row = dt.NewRow();
                        row["ID"] = DataTableUtils.toString(dt.Rows[i]["ID"]);
                        row["FinishTime"] = TextBox_AddDate.Text.Replace("-", "");
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                        //如果修改成功，存入LOG
                        if (DataTableUtils.Update_DataRow("DataSource", $"ID={DataTableUtils.toString(dt.Rows[i]["ID"])}", row))
                        {
                            GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                            sqlcmd = "select CAST ( ID AS INT ) as ID from dataSourceLog order by ID desc";
                            DataRow raw = DataTableUtils.DataTable_GetDataRow(sqlcmd);
                            sqlcmd = "select * from dataSourceLog";
                            dr = DataTableUtils.GetDataTable(sqlcmd);
                            if (dr != null)
                            {
                                try
                                {
                                    dt_count = DataTableUtils.toInt(DataTableUtils.toString(raw["ID"])) + 1;
                                }
                                catch
                                {
                                    dt_count = 1;
                                }
                                DataRow rew = dr.NewRow();
                                rew["ID"] = dt_count;
                                rew["ProductID"] = DataTableUtils.toString(dt.Rows[i]["ProductID"]);
                                rew["ProductSn"] = DataTableUtils.toString(dt.Rows[i]["ProductSn"]);
                                rew["FinishTime"] = TextBox_AddDate.Text.Replace("-", "");
                                rew["DeliveryTime"] = DataTableUtils.toString(dt.Rows[i]["DeliveryTime"]);
                                rew["SaveTime"] = DateTime.Now.ToString("yyyyMMddHHmmss");
                                rew["Reporter"] = HtmlUtil.Search_acc_Column(acc, "USER_NAME");
                                rew["Dispatch_staff"] = DataTableUtils.toString(dt.Rows[i]["Dispatch_staff"]);
                                rew["Dispatch_Date"] = DataTableUtils.toString(dt.Rows[i]["Dispatch_Date"]);
                                rew["Assignor"] = DataTableUtils.toString(dt.Rows[i]["Assignor"]);
                                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                                DataTableUtils.Insert_DataRow("dataSourceLog", rew);
                            }
                        }
                    }
                }
                html_code.Clear();
                //報工
                html_code.Add("active");
                html_code.Add("true");
                html_code.Add("active in");
                //派工
                html_code.Add("");
                html_code.Add("false");
                html_code.Add("");
            }
            load_data();
        }
        //搜尋
        protected void Button_Serarh_Click(object sender, EventArgs e)
        {
            load_data();
        }
        private void load_data()
        {
            Set_RadioButton(RadioButtonList_Man);
            Set_RadioButton(RadioButtonList_DispatchMan, true);
            Set_RadioButton(RadioButtonList_ReportMan, true);
            if (HtmlUtil.Search_acc_Column(acc, "Update_ELine") == "Y")
            {
                PlaceHolder_Dispatch.Visible = true;
                PlaceHolder_Report.Visible = true;
                class_name = "col-md-9 col-sm-12 col-xs-12";
            }
            else
            {
                PlaceHolder_Dispatch.Visible = false;
                PlaceHolder_Report.Visible = false;
                class_name = "col-md-12 col-sm-12 col-xs-12";
            }

            Set_DispatchDataTable();
            Set_ReportDataTable();

            if (TextBox_Temp.Text == "Dispatch")
            {
                html_code.Clear();
                //報工
                html_code.Add("");
                html_code.Add("false");
                html_code.Add("");
                //派工
                html_code.Add("active");
                html_code.Add("true");
                html_code.Add("active in");
            }
            else
            {
                html_code.Clear();
                //報工
                html_code.Add("active");
                html_code.Add("true");
                html_code.Add("active in");
                //派工
                html_code.Add("");
                html_code.Add("false");
                html_code.Add("");
            }


        }
        //設定派工單
        private void Set_DispatchDataTable()
        {
            Set_th_tr("Dispatch", out th_Dispatch, out tr_Dispatch, Asm_ELineDispatch_callback);
        }
        //設定報工單
        private void Set_ReportDataTable()
        {
            Set_th_tr("Report", out th_Report, out tr_Report, Asm_ELineReport_callback);
        }
        //設定RadioButtonList的值
        private void Set_RadioButton(RadioButtonList radio, bool Add_All = false)
        {
            if (radio.Items.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = "select * from ElectricControl_Staff where On_Job = 'Y'";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                ListItem list = new ListItem();
                if (Add_All)
                {
                    list = new ListItem("全部", "全部");
                    radio.Items.Add(list);
                }
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        list = new ListItem(DataTableUtils.toString(row["Staff"]), DataTableUtils.toString(row["Staff"]));
                        radio.Items.Add(list);
                    }
                }
            }
        }
        //派工單相關欄位處理方式
        private string Asm_ELineDispatch_callback(DataRow row, string field_name)
        {
            string value = "";
            if (field_name == "產品編號")//當欄位名稱=產品編號時，要讓他歸零，避免計算錯誤
                count = 0;
            string js_code = "";
            int No_Dispatch = 0;//未派工數量
            int n;
            //一般員工->顯示自己相關  主管->顯示他所設定的
            string staff = "";
            if (HtmlUtil.Search_acc_Column(acc, "Update_ELine") != "Y")//個人的部分
                staff = $" and Dispatch_staff='{HtmlUtil.Search_acc_Column(acc, "USER_NAME")}' ";
            else//主管的部分
            {
                switch (RadioButtonList_Dispatch.SelectedItem.Value)
                {
                    case "0":    //全部
                        staff = "";
                        break;
                    case "1":    //已派工
                        if (RadioButtonList_DispatchMan.SelectedItem.Value == "全部")
                            staff = " and (Dispatch_staff is not null and Dispatch_staff <> '' ) ";
                        else
                            staff = $" and Dispatch_staff='{RadioButtonList_DispatchMan.SelectedItem.Text}' ";
                        break;
                    case "2":    //未派工
                        staff = " and (Dispatch_staff is null or Dispatch_staff = '') ";
                        break;
                }
            }


            //顯示各日期的數量(已派 未派 個人)
            if (int.TryParse(field_name, out n))
            {
                //計算該日子要做的數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = $"select * from DataSource where ProductID='{DataTableUtils.toString(row["產品編號"])}' and DeliveryTime='{field_name}' {staff} ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                {
                    value = "" + dt.Rows.Count;
                    count += dt.Rows.Count;
                }
                else
                    value = "   ";

                //顯示可派工數量
                sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and (Dispatch_staff is null OR Dispatch_staff ='') and DeliveryTime >= '{field_name}'";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                    No_Dispatch = dt.Rows.Count;

                //顯示派工數量及人員

                sqlcmd = $"SELECT Dispatch_staff as 派工人員 ,count(Dispatch_staff) as 派工次數  FROM DataSource  where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and DeliveryTime = '{field_name}' and (Dispatch_staff is not null and Dispatch_staff <> '')  group by Dispatch_staff";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                string show_total = "";
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow data in dt.Rows)
                        show_total += DataTableUtils.toString(data["派工人員"]) + "：" + DataTableUtils.toString(data["派工次數"]) + "件&nbsp&nbsp";
                }


                //設定如果過去的話，就不讓他報工跟派工
                if (WebUtils.GetAppSettings("ELine_power") == "1")
                {
                    if (DataTableUtils.toInt(DateTime.Now.ToString("yyyyMMdd")) <= DataTableUtils.toInt(field_name))
                    {
                        if (RadioButtonList_Dispatch.SelectedItem.Value != "1")
                            js_code = $" onclick=Calculate_Number('{DataTableUtils.toString(row["產品編號"])}','{No_Dispatch}','{HtmlUtil.changetimeformat(field_name, "-")}','DispatchMan') data-toggle = \"modal\" data-target = \"#exampleModal_Dispatch\" ";
                        else
                            js_code = $" onclick=Update_Data('{DataTableUtils.toString(row["產品編號"])}','{HtmlUtil.changetimeformat(field_name, "-")}','{show_total}') data-toggle = \"modal\" data-target = \"#exampleModal_DispatchUpdate\"";
                    }
                }
                else
                {
                    if (RadioButtonList_Dispatch.SelectedItem.Value != "1")
                        js_code = $" onclick=Calculate_Number('{DataTableUtils.toString(row["產品編號"])}','{No_Dispatch}','{HtmlUtil.changetimeformat(field_name, "-")}','DispatchMan') data-toggle = \"modal\" data-target = \"#exampleModal_Dispatch\" ";
                    else
                        js_code = $" onclick=Update_Data('{DataTableUtils.toString(row["產品編號"])}','{HtmlUtil.changetimeformat(field_name, "-")}','{show_total}') data-toggle = \"modal\" data-target = \"#exampleModal_DispatchUpdate\"";
                }
            }
            else if (field_name == "總計")//顯示各數量
                value = "" + count;

            //一般員工的話，無法做派工的動作
            if (HtmlUtil.Search_acc_Column(acc, "Update_ELine") != "Y")
                js_code = "";


            if (value == "")
                return "";
            else
                return $"<td align='center' {js_code} >" + value + "</td>";
        }
        //報工單相關欄位處理方式
        private string Asm_ELineReport_callback(DataRow row, string field_name)
        {
            string value = "";
            if (field_name == "產品編號")//當欄位名稱=產品編號時，要讓他歸零，避免計算錯誤
                count = 0;
            string js_code = "";
            int No_Dispatch = 0;//未派工數量
            int n;
            int No_FinishCount = 0;
            //一般員工->顯示自己相關  主管->顯示他所設定的
            string staff = "";
            string condition = $"";
            if (HtmlUtil.Search_acc_Column(acc, "Update_ELine") != "Y")//個人的部分
            {
                condition = $" and FinishTime is not null and FinishTime='{field_name}'  ";
                staff = $" and Dispatch_staff='{HtmlUtil.Search_acc_Column(acc, "USER_NAME")}' ";
            }
            else
            {
                switch (RadioButtonList_Report.SelectedItem.Value)
                {
                    case "0":    //全部
                        staff = "";
                        condition = $" and Dispatch_staff is not null and DeliveryTime='{field_name}' ";
                        break;
                    case "1":    //已報工
                        if (RadioButtonList_ReportMan.SelectedItem.Value == "全部")
                        {
                            staff = " and (Dispatch_staff is not null and Dispatch_staff <> '') ";
                            condition = $" and FinishTime is not null and FinishTime='{field_name}'   ";
                        }
                        else
                        {
                            condition = $" and FinishTime is not null and FinishTime='{field_name}'  ";
                            staff = $" and Dispatch_staff='{RadioButtonList_ReportMan.SelectedItem.Text}' ";
                        }
                        break;
                    case "2":    //未報工
                        if (RadioButtonList_ReportMan.SelectedItem.Value == "全部")

                        {
                            staff = " and (Dispatch_staff is not null and Dispatch_staff <> '') ";
                            condition = $" and FinishTime is null and DeliveryTime='{field_name}'   ";
                        }
                        else
                        {
                            condition = $" and FinishTime is  null and DeliveryTime='{field_name}'  ";
                            staff = $" and Dispatch_staff='{RadioButtonList_ReportMan.SelectedItem.Text}' ";
                        }
                        break;
                }
            }
            //判斷日期
            if (int.TryParse(field_name, out n))
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = $"select * from DataSource where (Dispatch_staff is not null and Dispatch_staff <> '')  and ProductID='{DataTableUtils.toString(row["產品編號"])}' {staff} {condition} ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (dt != null && dt.Rows.Count > 0)
                {
                    value = "" + dt.Rows.Count;
                    count += dt.Rows.Count;
                }
                else
                    value = "  ";

                sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and FinishTime is null and (Dispatch_staff is not null and Dispatch_staff <> '' ) {staff} ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                    No_FinishCount = dt.Rows.Count;


                //設定如果過去的話，就不讓他報工跟派工
                if (WebUtils.GetAppSettings("ELine_power") == "1")
                {
                    if (DataTableUtils.toInt(DateTime.Now.ToString("yyyyMMdd")) <= DataTableUtils.toInt(field_name))
                        js_code = $" onclick=Calculate_Number('{DataTableUtils.toString(row["產品編號"])}','{No_FinishCount}','{HtmlUtil.changetimeformat(field_name, "-")}','Report') data-toggle = \"modal\" data-target = \"#exampleModal\" ";
                }
                else
                    js_code = $" onclick=Calculate_Number('{DataTableUtils.toString(row["產品編號"])}','{No_FinishCount}','{HtmlUtil.changetimeformat(field_name, "-")}','Report') data-toggle = \"modal\" data-target = \"#exampleModal\" ";
            }
            //總計
            else if (field_name == "總計")
                value = "" + count;

            //完成數量
            else if (field_name == "完成數量")
            {
                //整體完成數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and FinishTime is not null and (Dispatch_staff is not null and Dispatch_staff <> '' ) {staff}  ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                try
                {
                    value = "" + dt.Rows.Count;
                }
                catch
                {
                    value = "0";
                }

            }
            //截至今日止的完成數量
            else if (field_name == "進度")
            {
                //到當日為止的進度
                double finish = 0, no_finish = 0;
                double percent = 0;

                //取得全部要做的數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and DeliveryTime <= '{DateTime.Now.ToString("yyyyMMdd")}' and (Dispatch_staff is not null and  Dispatch_staff <> '' )  {staff}  ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (dt != null && dt.Rows.Count > 0)
                    no_finish = dt.Rows.Count;

                //取得已完成數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and FinishTime is not null and DeliveryTime <= '{DateTime.Now.ToString("yyyyMMdd")}' and (Dispatch_staff is not null and Dispatch_staff <> '')  {staff}   ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                    finish = dt.Rows.Count;

                if (no_finish == 0)
                    percent = 1;
                else
                    percent = finish / no_finish;

                value = Math.Round(percent * 100) + "%";
            }
            //截至最後一天的完成數量
            else if (field_name == "整體進度")
            {
                //到最後一天的進度
                double finish = 0, no_finish = 0;
                double percent = 0;

                //取得全部要做的數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and ( Dispatch_staff is not null and Dispatch_staff <> '' ) {staff}  ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (dt != null && dt.Rows.Count > 0)
                    no_finish = dt.Rows.Count;

                //取得已完成數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and FinishTime is not null and (Dispatch_staff is not null and Dispatch_staff <> '')  {staff}  ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                    finish = dt.Rows.Count;

                if (no_finish == 0)
                    percent = 1;
                else
                    percent = finish / no_finish;

                value = Math.Round(percent * 100) + "%";
            }
            if (value == "")
                return "";
            else
                return $"<td align='center' {js_code} >" + value + "</td>";
        }
        //設定表格欄位跟表格內容
        private void Set_th_tr(string type, out string th, out string tr, Func<DataRow, string, string> function = null)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
            string sqlcmd = "select distinct DeliveryTime from DataSource";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                string title = "";
                th_Report = HtmlUtil.Set_Table_Title(dt, out title, "DeliveryTime");
                title = "產品編號," + title + "總計,";
                //else
                //    title = "產品編號," + title + "總計,完成數量,進度,整體進度,";
                sqlcmd = "select distinct ProductID as 產品編號 from DataSource ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                {
                    List<string> list = new List<string>(title.Split(','));
                    for (int i = 1; i < list.Count - 1; i++)
                        dt.Columns.Add(list[i]);

                    th = HtmlUtil.Set_Table_Title(dt, out title);
                    tr = HtmlUtil.Set_Table_Content(dt, list, function);
                }
                else
                    HtmlUtil.NoData(out th, out tr);
            }
            else
                HtmlUtil.NoData(out th, out tr);
        }
        //刪除
        protected void Button_Delete_Click(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
            string sqlcmd = $"select * from DataSource where ProductID = '{TextBox_ProductUpdate.Text}' and DeliveryTime = '{TextBox_DateUpdate.Text.Replace("-", "")}'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    DataRow rew = dt.NewRow();
                    rew["ID"] = DataTableUtils.toString(row["ID"]);
                    rew["Dispatch_staff"] = "";
                    rew["Dispatch_Date"] = "";
                    rew["Assignor"] = "";
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                    bool ok = DataTableUtils.Update_DataRow("DataSource", $"ID='{DataTableUtils.toString(row["ID"])}'", rew);
                }
            }

            TextBox_Temp.Text = "Dispatch";
            load_data();
        }
    }
}

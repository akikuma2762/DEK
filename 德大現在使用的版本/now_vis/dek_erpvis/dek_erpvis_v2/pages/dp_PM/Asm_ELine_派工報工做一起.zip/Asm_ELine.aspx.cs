﻿using dek_erpvis_v2.cls;
using Support;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;


namespace dek_erpvis_v2.pages.dp_PM
{
    public partial class Asm_ELine : System.Web.UI.Page
    {
        public string color = "";
        public string th = "";
        public string tr = "";
        public string path = "";
        string acc = "";
        public string timerange = "";
        int count = 0;
        myclass myclass = new myclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                string URL_NAME = "Asm_ELine";
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                color = HtmlUtil.change_color(acc);
                if (myclass.user_view_check(URL_NAME, acc) == true || true)
                {
                    if (!IsPostBack)
                        Set_Table();
                }
                else
                    Response.Write("<script>alert('您無法瀏覽此頁面 請向該單位主管申請權限!');location.href='../index.aspx';</script>");
            }
            else
                Response.Redirect(myclass.logout_url);
        }
        //存入資料庫
        protected void Button_submit_Click(object sender, EventArgs e)
        {

            GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
            string sqlcmd = "";
            DataTable dt = new DataTable();
            DataTable dr = new DataTable();
            int dt_count = 1;
            //派工
            if (Session["Status"] != null && DataTableUtils.toString(Session["Status"]) == "DispatchMan")
            {
                sqlcmd = $"select * from DataSource where  ProductID = '{TextBox_Product.Text}' and Dispatch_staff is null order by ID asc ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                {
                    for (int i = 0; i < DataTableUtils.toInt(TextBox_DispatchCount.Text); i++)
                    {
                        DataRow row = dt.NewRow();
                        row["ID"] = DataTableUtils.toString(dt.Rows[i]["ID"]);
                        row["Dispatch_staff"] = RadioButtonList_Man.SelectedItem.Text;
                        row["Dispatch_Date"] = TextBox_DispatchTime.Text.Replace("-", "");
                        row["Assignor"] = HtmlUtil.Search_acc_Column(acc, "USER_NAME");
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                        DataTableUtils.Update_DataRow("DataSource", $"ID={DataTableUtils.toString(dt.Rows[i]["ID"])}", row);
                    }
                }
            }
            //報工
            else
            {
                sqlcmd = $"select * from DataSource where ProductID = '{TextBox_ID.Text}' and FinishTime is null order by ID asc ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                {
                    for (int i = 0; i < DataTableUtils.toInt(TextBox_count.Text); i++)
                    {
                        DataRow row = dt.NewRow();
                        row["ID"] = DataTableUtils.toString(dt.Rows[i]["ID"]);
                        row["FinishTime"] = TextBox_AddDate.Text.Replace("-", "");
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                        //如果修改成功，存入LOG
                        if (DataTableUtils.Update_DataRow("DataSource", $"ID={DataTableUtils.toString(dt.Rows[i]["ID"])}", row))
                        {
                            GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                            sqlcmd = "select CAST ( ID AS INT ) as ID from dataSourceLog order by ID desc";
                            DataRow raw = DataTableUtils.DataTable_GetDataRow(sqlcmd);
                            sqlcmd = "select * from dataSourceLog";
                            dr = DataTableUtils.GetDataTable(sqlcmd);
                            if (dr != null)
                            {
                                try
                                {
                                    dt_count = DataTableUtils.toInt(DataTableUtils.toString(raw["ID"])) + 1;
                                }
                                catch
                                {
                                    dt_count = 1;
                                }
                                DataRow rew = dr.NewRow();
                                rew["ID"] = dt_count;
                                rew["ProductID"] = DataTableUtils.toString(dt.Rows[i]["ProductID"]);
                                rew["ProductSn"] = DataTableUtils.toString(dt.Rows[i]["ProductSn"]);
                                rew["FinishTime"] = TextBox_AddDate.Text.Replace("-", "");
                                rew["DeliveryTime"] = DataTableUtils.toString(dt.Rows[i]["DeliveryTime"]);
                                rew["SaveTime"] = DateTime.Now.ToString("yyyyMMddHHmmss");
                                rew["Reporter"] = HtmlUtil.Search_acc_Column(acc, "USER_NAME");
                                rew["Dispatch_staff"] = DataTableUtils.toString(dt.Rows[i]["Dispatch_staff"]);
                                rew["Dispatch_Date"] = DataTableUtils.toString(dt.Rows[i]["Dispatch_Date"]);
                                rew["Assignor"] = DataTableUtils.toString(dt.Rows[i]["Assignor"]);
                                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                                DataTableUtils.Insert_DataRow("dataSourceLog", rew);
                            }
                        }
                    }
                }
            }
            Set_Table();
        }
        //產生前端顯示的DataTable
        private void Set_Table()
        {
            Set_CheckboxList();

            GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
            string sqlcmd = "select distinct DeliveryTime from DataSource";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            string title = "";
            th = HtmlUtil.Set_Table_Title(dt, out title, "DeliveryTime");
            title = "產品編號," + title + "總計,完成數量,進度,整體進度,";
            sqlcmd = "select distinct ProductID as 產品編號 from DataSource ";
            dt = DataTableUtils.GetDataTable(sqlcmd);
            List<string> list = new List<string>(title.Split(','));
            for (int i = 1; i < list.Count - 1; i++)
                dt.Columns.Add(list[i]);

            th = HtmlUtil.Set_Table_Title(dt, out title);
            tr = HtmlUtil.Set_Table_Content(dt, list, Asm_ELine_callback);
        }
        //相關欄位的處理方式
        private string Asm_ELine_callback(DataRow row, string field_name)
        {
            string value = "";

            if (field_name == "產品編號")
                count = 0;
            string js_code = "";
            int No_FinishCount = 0;
            int n;
            //判斷日子
            if (int.TryParse(field_name, out n))
            {
                //計算該日子要做的數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = $"select * from DataSource where ProductID='{DataTableUtils.toString(row["產品編號"])}' and DeliveryTime='{field_name}'  ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (dt != null && dt.Rows.Count > 0)
                {
                    value = "" + dt.Rows.Count;
                    count += dt.Rows.Count;
                }
                else
                    value = "   ";
                ////計算該日子已完工數量
                //GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                //sqlcmd = $"select * from DataSource where ProductID='{DataTableUtils.toString(row["產品編號"])}' and FinishTime='{field_name}' ";
                //dt = DataTableUtils.GetDataTable(sqlcmd);
                //if (dt != null && dt.Rows.Count > 0 && DataTableUtils.toInt(DataTableUtils.toString(dt.Rows[0]["FinishTime"])) <= DataTableUtils.toInt(DataTableUtils.toString(dt.Rows[0]["DeliveryTime"])))
                //    value = "<b style='color:green'>" + dt.Rows.Count + "</b>   " + value;
                //else if (dt != null && dt.Rows.Count > 0 && DataTableUtils.toInt(DataTableUtils.toString(dt.Rows[0]["FinishTime"])) > DataTableUtils.toInt(DataTableUtils.toString(dt.Rows[0]["DeliveryTime"])))
                //    value = "<b style='color:red'>" + dt.Rows.Count + "</b>   " + value;


                //
                string type = "exampleModal";
                if (Session["Status"] != null && DataTableUtils.toString(Session["Status"]) == "DispatchMan")
                {
                    sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and Dispatch_staff is null and DeliveryTime >= '{field_name}'";
                    type = "exampleModal_Dispatch";
                }
                else
                {
                    sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and FinishTime is null ";
                    type = "exampleModal";
                }
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                    No_FinishCount = dt.Rows.Count;

                //設定如果過去的話，就不讓他報工跟派工
                if (WebUtils.GetAppSettings("ELine_power") == "1")
                {
                    if (DataTableUtils.toInt(DateTime.Now.ToString("yyyyMMdd")) <= DataTableUtils.toInt(field_name))
                        js_code = $" onclick=Calculate_Number('{DataTableUtils.toString(row["產品編號"])}','{No_FinishCount}','{HtmlUtil.changetimeformat(field_name, "-")}','{DataTableUtils.toString(Session["Status"])}') data-toggle = \"modal\" data-target = \"#{type}\" ";
                }
                else
                    js_code = $" onclick=Calculate_Number('{DataTableUtils.toString(row["產品編號"])}','{No_FinishCount}','{HtmlUtil.changetimeformat(field_name, "-")}','{DataTableUtils.toString(Session["Status"])}') data-toggle = \"modal\" data-target = \"#{type}\" ";

            }
            else if (field_name == "總計")
                value = "" + count;
            else if (field_name == "完成數量")
            {
                //整體完成數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and FinishTime is not null ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                try
                {
                    value = "" + dt.Rows.Count;
                }
                catch
                {
                    value = "0";
                }

            }
            else if (field_name == "進度")
            {
                //到當日為止的進度
                double finish = 0, no_finish = 0;
                double percent = 0;

                //取得全部要做的數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and DeliveryTime <= '{DateTime.Now.ToString("yyyyMMdd")}' ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (dt != null && dt.Rows.Count > 0)
                    no_finish = dt.Rows.Count;

                //取得已完成數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and FinishTime is not null and DeliveryTime <= '{DateTime.Now.ToString("yyyyMMdd")}'  ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                    finish = dt.Rows.Count;

                if (no_finish == 0)
                    percent = 1;
                else
                    percent = finish / no_finish;

                value = Math.Round(percent * 100) + "%";
            }
            else if (field_name == "整體進度")
            {
                //到最後一天的進度
                double finish = 0, no_finish = 0;
                double percent = 0;

                //取得全部要做的數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (dt != null && dt.Rows.Count > 0)
                    no_finish = dt.Rows.Count;

                //取得已完成數量
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                sqlcmd = $"select * from DataSource where ProductID = '{DataTableUtils.toString(row["產品編號"])}' and FinishTime is not null ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null && dt.Rows.Count > 0)
                    finish = dt.Rows.Count;

                if (no_finish == 0)
                    percent = 1;
                else
                    percent = finish / no_finish;

                value = Math.Round(percent * 100) + "%";
            }
            else if (field_name == "詳細資料")
            {
                value = "詳細資料";
                js_code = $" data-toggle = \"modal\" data-target = \"#exampleModal_Detail\" ";
            }

            if (value == "")
                return "";
            else
                return $"<td align='center' {js_code} >" + value + "</td>";
        }
        //設定CheckboxList的值
        private void Set_CheckboxList()
        {
            if (RadioButtonList_Man.Items.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDetaELine);
                string sqlcmd = "select * from ElectricControl_Staff where On_Job = 'Y'";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                ListItem list = new ListItem();
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        list = new ListItem(DataTableUtils.toString(row["Staff"]), DataTableUtils.toString(row["Staff"]));
                        RadioButtonList_Man.Items.Add(list);
                    }
                }
            }
        }
        //轉換狀態 報工<->派工
        protected void Button_Action_Click(object sender, EventArgs e)
        {
            string status = DataTableUtils.toString(((Control)sender).ID.Split('_')[1]);
            Session["Status"] = status;
            switch (status)
            {
                case "Report":
                    Button_Report.Text = "報工中";
                    Button_DispatchMan.Text = "派工";
                    break;
                case "DispatchMan":
                    Button_Report.Text = "報工";
                    Button_DispatchMan.Text = "派工中";
                    break;
            }
            Set_Table();
        }
    }
}
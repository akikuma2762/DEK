﻿using dek_erpvis_v2.cls;
using Support;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace dek_erpvis_v2.pages.dp_CNC
{
    public partial class Machine_list_info_details : System.Web.UI.Page
    {
        public string color = "";
        public string date_str = "";//new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).ToString("yyyyMMdd");
        public string date_end = ""; //new DateTime(DateTime.Now.AddMonths(1).Year, DateTime.Now.AddMonths(1).Month, 1).AddDays(-1).ToString("yyyyMMdd");
        public string th = "";
        public string tr = "";
        public string data_name = "";
        public string title_text = "";
        public string path = "";
        string acc = "";
        public string 交易天數 = "";
        public string timerange = "";
        public string machine = "";
        public string area = "";
        public string str_First_Day = "";
        public string str_Last_Day = "";
        public string str_Dev_Name = "";
        public string js_code = "";
        public string condition;
        public string pie_data_points = "";
        ShareFunction SFun = new ShareFunction();
        int i = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                color = HtmlUtil.change_color(acc);
                if (TextBox_date.Text == "")
                    TextBox_date.Text = DateTime.Now.ToString("yyyy-MM-dd");
                Gocenn();
            }
            else
                Response.Redirect(myclass.logout_url);

        }
        //存入資料庫
        protected void Button_submit_Click(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            //舊的
            //string sqlcmd = $"SELECT * FROM status_history_info where _id = '{TextBox_ID.Text}'";
            //DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

            //if (dt != null && dt.Rows.Count > 0)
            //{
            //    DataRow row = dt.NewRow();
            //    row["_id"] = DataTableUtils.toString(dt.Rows[0]["_id"]);
            //    row["Type"] = DropDownList_Status.SelectedItem.Text;
            //    row["Detail"] = TextBox_content.Text;
            //    bool ok = DataTableUtils.Update_DataRow("status_history_info", $"_id = '{TextBox_ID.Text}'", row);
            //}

            //做新增的動做
            if (TextBox_Father.Text != "update")
            {
                string sqlcmd = "";
                DataTable dt = new DataTable();
                int count = 0;
                //先找出該資料表內最大的ID
                sqlcmd = "Select * from error_report order by 異常維護編號  desc ";
                dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt != null)
                {
                    try
                    {
                        count = DataTableUtils.toInt(DataTableUtils.toString(dt.Rows[0]["異常維護編號"])) + 1;
                    }
                    catch
                    {
                        count = 1;
                    }
                }
                //處理中
                if (DropDownList_nowstatus.SelectedItem.Value == "0")
                {
                    sqlcmd = "Select * from error_report";
                    dt = DataTableUtils.GetDataTable(sqlcmd);
                    if (dt != null)
                    {
                        DataRow row = dt.NewRow();
                        row["異常維護編號"] = count;
                        row["異常編號"] = TextBox_ID.Text;
                        row["維護人員姓名"] = HtmlUtil.Search_acc_Column(acc, "USER_NAME");
                        row["維護人員單位"] = HtmlUtil.Search_acc_Column(acc, "USER_DPM");
                        row["異常原因類型"] = DropDownList_Type.SelectedItem.Text;
                        row["維護內容"] = TextBox_content.Text;
                        row["時間紀錄"] = DateTime.Now.ToString("yyyyMMddHHmmss");
                        //這裡只需要輸入資料夾，槽的話，放在webconfig內部以供更改
                        row["圖片檔名"] = HtmlUtil.FileUpload_Name(FileUpload_File, "cnc_error");
                        row["父編號"] = TextBox_Father.Text;
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                        bool ok = DataTableUtils.Insert_DataRow("error_report", row);
                    }
                }
                //結案
                else if (DropDownList_nowstatus.SelectedItem.Value == "1" && TextBox_ID.Text == "")
                {
                    sqlcmd = $"select * from error_report where 異常維護編號 = '{TextBox_Father.Text}'";
                    dt = DataTableUtils.GetDataTable(sqlcmd);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        DataRow row = dt.NewRow();
                        row["異常維護編號"] = count;
                        row["父編號"] = TextBox_Father.Text;
                        row["維護人員姓名"] = HtmlUtil.Search_acc_Column(acc, "USER_NAME");
                        row["維護人員單位"] = HtmlUtil.Search_acc_Column(acc, "USER_DPM");
                        row["結案判定類型"] = DropDownList_Type.SelectedItem.Text;
                        row["結案內容"] = TextBox_content.Text;
                        row["時間紀錄"] = DateTime.Now.ToString("yyyyMMddHHmmss");
                        //這裡只需要輸入資料夾，槽的話，放在webconfig內部以供更改
                        row["結案附檔"] = HtmlUtil.FileUpload_Name(FileUpload_File, "cnc_close");
                        GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                        bool ok = DataTableUtils.Insert_DataRow("error_report", row);
                    }

                }
                else
                    Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", "<script>alert('資料庫連接異常');location.href='Machine_list_info_details.aspx" + Request.Url.Query + "';</script>");
            }
            //做更新的動作
            else if (TextBox_Father.Text == "update")
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = $"select * from error_report where 異常維護編號 = '{TextBox_ID.Text}'";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (dt != null && dt.Rows.Count > 0)
                {
                    DataRow row = dt.NewRow();
                    row["異常維護編號"] = DataTableUtils.toString(dt.Rows[0]["異常維護編號"]);
                    //處理中
                    if (DataTableUtils.toString(dt.Rows[0]["結案判定類型"]) == "")
                    {
                        row["異常原因類型"] = DropDownList_Type.SelectedItem.Text;
                        row["維護內容"] = TextBox_content.Text;
                    }
                    //結案
                    else if (DataTableUtils.toString(dt.Rows[0]["結案判定類型"]) != "")
                    {
                        row["結案判定類型"] = DropDownList_Type.SelectedItem.Text;
                        row["結案內容"] = TextBox_content.Text;
                    }
                    bool ok = DataTableUtils.Update_DataRow("error_report", $"異常維護編號 = '{TextBox_ID.Text}'", row);
                }
            }

            Gocenn();
        }
        //從資料庫找值後回填至元件內
        protected void Button_Search_Click(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from error_report where 異常維護編號 = '{TextBox_ID.Text}'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

            if (dt != null && dt.Rows.Count > 0)
            {
                if (DataTableUtils.toString(dt.Rows[0]["結案判定類型"]) == "")
                {
                    DropDownList_nowstatus.SelectedValue = "0";
                    DropDownList_Type.SelectedValue = DataTableUtils.toString(dt.Rows[0]["異常原因類型"]);
                    TextBox_content.Text = DataTableUtils.toString(dt.Rows[0]["維護內容"]);
                }
                else
                {
                    DropDownList_nowstatus.SelectedValue = "1";
                    DropDownList_Type.SelectedValue = DataTableUtils.toString(dt.Rows[0]["結案判定類型"]);
                    TextBox_content.Text = DataTableUtils.toString(dt.Rows[0]["結案內容"]);
                }
            }
        }
        //刪除
        protected void bt_del_ServerClick(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from error_report where 異常維護編號='{TextBox_ID.Text}'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

            if (dt != null && dt.Rows.Count > 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                DataTableUtils.Delete_Record("error_report", $"異常維護編號='{TextBox_ID.Text}'");
            }
            Gocenn();
        }
        //搜尋
        protected void button_select_Click(object sender, EventArgs e)
        {
            Gocenn();
        }
        //檢查跟執行function
        private void Gocenn()
        {
            Response.Buffer = false;
            machine = "";

            if (Request.QueryString["key"] != null)
            {
                Dictionary<string, string> keyValues = HtmlUtil.Return_dictionary(Request.QueryString["key"]);
                machine = HtmlUtil.Search_Dictionary(keyValues, "machine");
                Set_Dropdownlist();
                Set_bar();
                Set_Html_Table();
                Set_Percent();
                machine = CNCUtils.MachName_translation(machine);
            }
            else
                Response.Redirect("Machine_list_info.aspx", false);

            ////測試用
            //machine = "D14MiA1";
            //Set_Dropdownlist();
            //Set_bar();
            //Set_Html_Table();
            //Set_Percent();
            //machine = CNCUtils.MachName_translation(machine);
        }
        //產生上下午的BAR
        private void Set_bar()
        {
            area = "";
            js_code = "";
            str_Dev_Name = machine;
            str_First_Day = TextBox_date.Text.Replace('-', '/');
            str_Last_Day = DateTime.Parse(str_First_Day).AddDays(1).ToString("yyyy/MM/dd");
            //0-12
            js_code += "mTimer_status = setTimeout(function () { draw_Axial('" + machine + "',''); }, 1000);\n";
            area += "           <div id = 'ma_div_" + machine + "' class=\"scrollbar\">";
            area += "<canvas id = 'ma_canvas_" + machine + "' width = '1200' height = '105'></canvas>";
            area += "           </div>\n";
            //12-24
            js_code += "mTimer_status = setTimeout(function () { draw_Axial('" + machine + "','1'); }, 1000);\n";
            area += "           <div id = 'ma_div_" + machine + "1' class=\"scrollbar\">";
            area += "<canvas id = 'ma_canvas_" + machine + "1' width = '1200' height = '105'></canvas>";
            area += "           </div>\n";
        }
        //產生DATATABLE
        private void Set_Html_Table()
        {
            condition = get_condition(CheckBoxList_status);
            int time = 0;
            time = Int16.Parse(TextBox_time.Text) * 60;

            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"SELECT     " +
                            $"status_change.status_chinese as 狀態,    " +
                            $"mach_show_name AS 異警資訊,    " +
                            $"update_time as 開始時間,   " +
                            $"enddate_time as 結束時間,    " +
                            $"  CAST(timespan AS double) as 持續時間,    " +
                            //     $"Type as 類型,   " +
                            $" Detail as 內容, " +
                            $" status_history_info._id as 新增 " +
                            $"FROM    status_history_info        " +
                            $"LEFT JOIN    machine_info ON machine_info.mach_name = status_history_info.mach_name    " +
                            $"Left join status_change on status_history_info.status = status_change.status_english     " +
                            $"where  CAST(timespan AS signed)  > {time}	" +
                            $"and    status_history_info.mach_name = '{machine}'    " +
                            $"and    CAST(update_time AS double) >= '{TextBox_date.Text.Replace("-", "")}000000'	" +
                            $"and    CAST(update_time AS double) <= '{TextBox_date.Text.Replace("-", "")}235959'" +
                            $" {condition} ";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            ////抓到前一天的最後一筆
            sqlcmd = $"SELECT     " +
                           $"status_change.status_chinese as 狀態,    " +
                           $"mach_show_name AS 異警資訊,    " +
                           $"update_time as 開始時間,   " +
                           $"enddate_time as 結束時間,    " +
                           $"  CAST(timespan AS double) as 持續時間,    " +
                           //       $"Type as 類型,   " +
                           $" Detail as 內容, " +
                           $" status_history_info._id as 操作 " +
                           $"FROM    status_history_info        " +
                           $"LEFT JOIN    machine_info ON machine_info.mach_name = status_history_info.mach_name    " +
                           $"Left join status_change on status_history_info.status = status_change.status_english     " +
                           $"where  CAST(timespan AS signed)  > {time}	" +
                           $"and    status_history_info.mach_name = '{machine}'    " +
                           $"and    CAST(update_time AS double) <= '{TextBox_date.Text.Replace("-", "")}000000'	" +
                           $"and    CAST(enddate_time AS double) >= '{TextBox_date.Text.Replace("-", "")}000000'	" +
                           $" {condition} " +
                           $"order by status_history_info._id desc limit 1";
            DataTable dr = DataTableUtils.GetDataTable(sqlcmd);
            try
            {
                dt.Merge(dr, true, MissingSchemaAction.Ignore);
            }
            catch
            {

            }
            //如果是今天，抓當下的這一筆
            if (TextBox_date.Text.Replace("-", "").Contains(DateTime.Now.ToString("yyyyMMdd")))
            {
                sqlcmd = $"SELECT " +
                         $"status_chinese AS 狀態," +
                         $"mach_show_name As 異警資訊," +
                         $"update_time as 開始時間 " +
                         $"FROM    status_currently_info        " +
                         $"LEFT JOIN    status_change ON status_change.status_english = status_currently_info.status    " +
                         $"left join machine_info    on status_currently_info.mach_name = machine_info.mach_name    " +
                         $" where status_currently_info.mach_name = '{machine}' " + condition;
                DataTable dt_now = DataTableUtils.GetDataTable(sqlcmd);
                try
                {
                    dt.Merge(dt_now, true, MissingSchemaAction.Ignore);
                }
                catch
                {

                }
            }
            condition = WebUtils.UrlStringEncode(condition + $" and CAST(timespan AS signed)  > {time} ");
            string title = "";
            th = HtmlUtil.Set_Table_Title(dt, out title);
            tr = HtmlUtil.Set_Table_Content(dt, title, Machine_list_info_details_callback);
        }
        //欄位的處理
        private string Machine_list_info_details_callback(DataRow row, string field_name)
        {
            string value = "";
            if (field_name == "開始時間" || field_name == "結束時間")
            {
                try
                {
                    value = Convert.ToDateTime(DateTime.ParseExact(DataTableUtils.toString(row[field_name]), "yyyyMMddHHmmss.f", System.Globalization.CultureInfo.CurrentCulture)).ToString("yyyy/MM/dd HH:mm:ss");
                }
                catch
                {
                    value = "  ";
                }
            }
            else if (field_name == "持續時間")
            {
                if (DataTableUtils.toString(row[field_name]) != "")
                {
                    int seconds = DataTableUtils.toInt(DataTableUtils.toString(row[field_name]).Split('.')[0]);
                    var timespan = TimeSpan.FromSeconds(seconds);
                    string day = "";
                    if (timespan.ToString("%d") != "0")
                        day = timespan.ToString("%d") + " 天  ";
                    value = day + timespan.ToString(@"hh\:mm\:ss");
                }
                else
                    value = "  ";
            }
            else if (field_name == "新增")
            {
                if (DataTableUtils.toString(row[field_name]) != "")
                    value = $"<b><u><a id={DataTableUtils.toString(row[field_name])} onclick=insert_content('{DataTableUtils.toString(row[field_name])}') data-toggle = \"modal\" data-target = \"#exampleModal\">新增</a></u></b>";
                else
                    value = "    ";
            }
            else if (field_name == "異警資訊")
            {
                if (DataTableUtils.toString(row["狀態"]) == "警報")
                {
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    string sqlcmd = $"SELECT     alarm_type," +
                                    $"alarm_num," +
                                    $"alarm_mesg " +
                                    $"FROM     status_history_info " +
                                    $"left join alarm_history_info " +
                                    $"on alarm_history_info.mach_name  =  status_history_info.mach_name  " +
                                    $"and alarm_history_info.update_time = status_history_info.update_time " +
                                    $"and alarm_history_info.timespan = status_history_info.timespan " +
                                    $"LEFT JOIN    machine_info ON machine_info.mach_name = status_history_info.mach_name   " +
                                    $"where (status_history_info.status = 'EMERGENCY' OR status_history_info.status = 'ALARM') " +
                                    $"and  mach_show_name = '{DataTableUtils.toString(row["異警資訊"])}' " +
                                    $"and alarm_history_info.update_time = '{DataTableUtils.toString(row["開始時間"])}' " +
                                    $"and alarm_history_info.timespan = '{DataTableUtils.toString(row["持續時間"])}' " +
                                    $"order by status_history_info._id desc limit 1 ";
                    DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                    if (dt != null && dt.Rows.Count > 0)
                        value = DataTableUtils.toString(dt.Rows[0]["alarm_type"]) + "-" + DataTableUtils.toString(dt.Rows[0]["alarm_num"]) + "-" + DataTableUtils.toString(dt.Rows[0]["alarm_mesg"]);
                    else
                        value = "   ";
                }
                else
                    value = "   ";

            }
            else if (field_name == "內容")
            {
                //List<string> list = new List<string>(DataTableUtils.toString(row[field_name]).Split('\n'));
                //for (int i = 0; i < list.Count; i++)
                //    value += list[i] + " <br> ";

                value = Create_Content(DataTableUtils.toString(row["新增"]));
            }
            else if (field_name == "類型")
            {

            }
            if (value == "")
                return value;
            else
                return "<td>" + value + "</td>\n";
        }
        //設定選取的個數
        private string get_condition(CheckBoxList checkBoxList)
        {
            string condition = "";

            for (int i = 0; i < checkBoxList.Items.Count; i++)
            {
                if (checkBoxList.Items[i].Selected)
                {
                    if (condition == "")
                        condition += $" and ( status_chinese ='{checkBoxList.Items[i].Text}' ";
                    else
                        condition += $" OR  status_chinese ='{checkBoxList.Items[i].Text}' ";
                }
            }
            if (condition == "")
                return "";
            else
                return condition + ")";
        }
        //在Dropdownlist設置ITEM
        private void Set_Dropdownlist()
        {
            if (DropDownList_Type.Items.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = "SELECT * FROM status_type";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                ListItem listItem = new ListItem();
                foreach (DataRow row in dt.Rows)
                {
                    listItem = new ListItem(DataTableUtils.toString(row["type"]), DataTableUtils.toString(row["type"]));
                    DropDownList_Type.Items.Add(listItem);
                }
            }

        }
        //產生運轉 警報 待機  離線的%
        private void Set_Percent()
        {
            pie_data_points = "";
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from status_realtime_info where mach_name='{machine}' and work_date='{TextBox_date.Text.Replace("-", "")}'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

            if (dt != null && dt.Rows.Count > 0)
            {

                pie_data_points += "{y:" + DataTableUtils.toInt(DataTableUtils.toString(dt.Rows[0]["operate_rate_now"])) + ", name:'運轉' , label:'運轉',color:'#04ba27'}," +
                                    "{y:" + DataTableUtils.toInt(DataTableUtils.toString(dt.Rows[0]["idle_rate_now"])) + ", name:'待機' , label:'待機',color:'#fe9900'}," +
                                    "{y:" + DataTableUtils.toInt(DataTableUtils.toString(dt.Rows[0]["alarm_rate_now"])) + ", name:'警報' , label:'警報',color:'#ff0000'}," +
                                    "{y:" + DataTableUtils.toInt(DataTableUtils.toString(dt.Rows[0]["disc_rate_now"])) + ", name:'離線' , label:'離線',color:'#737373'},";
            }
        }
        //產生內容
        private string Create_Content(string Error_Number)
        {
            string value = "";
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from error_report where 異常編號='{Error_Number}'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            DataTable dt_child = new DataTable();
            List<string> list = new List<string>();

            if (dt != null && dt.Rows.Count > 0)
            {
                value += "<div class=\"col-md-12 col-xs-12\" style=\" margin:0px 25px 0px 0px;\" align=\"center\">" +
                            "<u>" +
                              $"<a data-toggle=\"collapse\" data-parent=\"#accordion\"  href=\"#collapseall{i}\" onclick=change_icon('icon{i}','text{i}') >" +
                                   $"<b id=\"text{i}\"  style=\"color:black\" >展開   </b>  <i id=\"icon{i}\"  class=\"fa fa-plus-circle\" style=\"color:black;width:3%;font-size: 1.4em;\"></i>\n" +
                                "</a>" +
                            "</u>" +
                        "</div>" +
                $"<div id=\"collapseall{i}\" class=\"panel-collapse collapse\">" +
                $"<br /><br />";
                //這裡是內容
                foreach (DataRow row in dt.Rows)
                {
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    sqlcmd = $"select * from error_report where 父編號='{DataTableUtils.toString(row["異常維護編號"])}' order by 時間紀錄 asc";
                    //檢查是否含有子項目
                    dt_child = DataTableUtils.GetDataTable(sqlcmd);
                    //產生icon跟子項目內容
                    list = Create_ChildContent(dt_child, DataTableUtils.toString(row["異常維護編號"]));
                    //回傳的PDF,WORD,EXCEL,PPT
                    string file = "";
                    //回傳的影片或是圖片
                    string video = "";
                    file = SFun.Return_fileurl(DataTableUtils.toString(row["圖片檔名"]), out video, "135");
                    value += "<div class=\"col-md-12 col-xs-12\">" +
                                list[0] +
                                $"[{DataTableUtils.toString(row["維護人員姓名"])}]：" + SFun.br_text(DataTableUtils.toString(row["維護內容"])) + file + video +
                                $"<div class=\"col-md-12 col-xs-12 text-right\" style=\"width:100%\">" +
                                    //回復
                                    $"<div class=\"col-md-offset-4 col-xs-4\"><a href='javascript:void(0)' onclick=recovery('{DataTableUtils.toString(row["異常維護編號"])}')  data-toggle = \"modal\" data-target = \"#exampleModal\">回覆</a></div>" +
                                    //編輯
                                    $"<div class=\"col-md-2 col-xs-4\"><a href='javascript:void(0)' onclick=update('{DataTableUtils.toString(row["異常維護編號"])}')  data-toggle = \"modal\" data-target = \"#exampleModal\">編輯</a></div>" +
                                    //刪除
                                    $"<div class=\"col-md-2 col-xs-4\" ><a href='javascript:void(0)' onclick=deletes('{DataTableUtils.toString(row["異常維護編號"])}') ><u>刪除</u></a></div>" +
                                $"</div>" +
                                "<div class=\"col-md-12 col-xs-12\" style=\"text-align:right;\">" +
                                    Convert.ToDateTime(DateTime.ParseExact(DataTableUtils.toString(row["時間紀錄"]), "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture)).ToString("yyyy/MM/dd HH:mm:ss") +
                                    "<hr />" +
                                "</div>" +
                                //展開 || 縮合子項目的DIV
                                $"<div id=\"collapse{DataTableUtils.toString(row["異常維護編號"])}\"  class=\"panel-collapse collapse \">" +
                                    "<div class=\"panel-body\">" +
                                    //子項目
                                    list[1] +
                                    "</div>" +
                                $"</div>" +
                            $"</div>";
                }

                value += "</div>";
                i++;
            }

            return value;
        }
        //產生子項目內容
        private List<string> Create_ChildContent(DataTable dt, string id)
        {
            string value = "";
            string icon = "";
            List<string> list = new List<string>();

            string video = "", file = "";
            if (dt != null && dt.Rows.Count > 0)
            {
                //印出icon
                icon = "<div class=\"col-md-1 col-xs-12\" style=\"width: 3%; margin:0px 25px 0px 0px \">" +
                            "<u>" +
                              $"<a data-toggle=\"collapse\" data-parent=\"#accordion\"  href=\"#collapse{id}\" >" +
                                   $"<i id=\"Open{id}\" onclick=Click_Num('Open{id}') class='fa fa-chevron-circle-down'  style='color:black;width:3%;font-size: 1.6em;'>" +
                                    "</i>" +
                                "</a>" +
                            "</u>" +
                        "</div>";


                //印出子項目
                foreach (DataRow row in dt.Rows)
                {
                    //未結案的情況
                    if (DataTableUtils.toString(row["結案判定類型"]) == "")
                    {
                        file = SFun.Return_fileurl(DataTableUtils.toString(row["圖片檔名"]), out video, "135");
                        value += "<div class='col-md-12 col-xs-12 col-sm-12'>" +
                                $"[{DataTableUtils.toString(row["維護人員姓名"])}]：" + SFun.br_text(DataTableUtils.toString(row["維護內容"])) + file + video +
                                    $"<div class=\"col-md-12 col-xs-12 text-right\" style=\"width:100%\">" +
                                        //編輯
                                        $"<div class=\"col-md-offset-6 col-xs-4\"><a href='javascript:void(0)' onclick=update('{DataTableUtils.toString(row["異常維護編號"])}')  data-toggle = \"modal\" data-target = \"#exampleModal\">編輯</a></div>" +
                                        //刪除
                                        $"<div class=\"col-md-2 col-xs-4\" ><a href='javascript:void(0)' onclick=deletes('{DataTableUtils.toString(row["異常維護編號"])}') ><u>刪除</u></a></div>" +
                                    $"</div>" +
                                    "<div class=\"col-md-12 col-xs-12\" style=\"text-align:right;\">" +
                                        Convert.ToDateTime(DateTime.ParseExact(DataTableUtils.toString(row["時間紀錄"]), "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture)).ToString("yyyy/MM/dd HH:mm:ss") +
                                    "<hr />" +
                                    "</div>" +
                                 "</div>";
                    }
                    //表示已經結案
                    else if (DataTableUtils.toString(row["結案判定類型"]) != "")
                    {
                        file = SFun.Return_fileurl(DataTableUtils.toString(row["結案附檔"]), out video, "135");
                        value += "<div class='col-md-12 col-xs-12 col-sm-12'>" +
                                $"<b><span style='color:green'>[{DataTableUtils.toString(row["維護人員姓名"])}]</span>：" + SFun.br_text(DataTableUtils.toString(row["結案內容"])) + "</b>" + file + video +
                                    $"<div class=\"col-md-12 col-xs-12 text-right\" style=\"width:100%\">" +
                                        //編輯
                                        $"<div class=\"col-md-offset-6 col-xs-4\"><a href='javascript:void(0)' onclick=updatedate('{DataTableUtils.toString(row["異常維護編號"])}')  data-toggle = \"modal\" data-target = \"#exampleModal\">編輯</a></div>" +
                                        //刪除
                                        $"<div class=\"col-md-2 col-xs-4\" ><a href='javascript:void(0)' onclick=deletes('{DataTableUtils.toString(row["異常維護編號"])}') ><u>刪除</u></a></div>" +
                                    $"</div>" +
                                    "<div class=\"col-md-12 col-xs-12\" style=\"text-align:right;\">" +
                                        Convert.ToDateTime(DateTime.ParseExact(DataTableUtils.toString(row["時間紀錄"]), "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture)).ToString("yyyy/MM/dd HH:mm:ss") +
                                    "<hr />" +
                                    "</div>" +
                                 "</div>";
                    }

                }
            }
            list.Add(icon);
            list.Add(value);

            return list;
        }
    }
}
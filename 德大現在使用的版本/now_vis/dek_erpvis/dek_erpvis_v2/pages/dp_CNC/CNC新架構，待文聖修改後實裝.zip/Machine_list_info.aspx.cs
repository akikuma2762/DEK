﻿using System;
using Support;
using dek_erpvis_v2.cls;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI.WebControls;
using System.Data;
using System.Web.UI;

namespace dek_erpvis_v2.pages.dp_CNC
{
    public partial class Machine_list_info : System.Web.UI.Page
    {
        //丟到前端的資料
        public string color = "";
        double mach_count = 0;//機台總數
        public int run = 0;//運轉
        public int rest = 0;//待機
        public int alert = 0;//警告
        public int noline = 0;//離線
        public double percent = 0;//稼動率
        public double progress = 0;//生產進度
        public string js_code = "";
        //丟到前端的資料
        public DateTime FirstDay = new DateTime();
        public DateTime LastDay = new DateTime();
        public string str_First_Day = "";
        public string str_Last_Day = "";
        public string str_Dev_Status = "";
        public string dev_name = "";
        public double[] Panel_StatusValue = { 0, 0, 0, 0 };//operate//stop//alarm//disconnect
        public List<string> dev_list = null;
        public List<string> ls_data = new List<string>();
        public bool is_ok = false;
        public DataTable dt_data = null;
        CNC_Web_Data Web_Data = new CNC_Web_Data();
        public string Refresh_Time = "";
        public string th = "";
        public string tr = "";
        public string area = "";
        public string acc = "";
        string URL_NAME = "";
        string order_num = "";
        public string str_status = "";
        public string str_Dev_Name = "";

        public bool b_Page_Load = true;
        myclass myclass = new myclass();
        CNCUtils cNC_Class = new CNCUtils();
        public string Gantt_Data = "";
        public string Calculation_td = "";
        List<string> list = new List<string>();
        public string show_gantt_image = "";
        int mach_number = 0;
        public string ok = "false";
        enum classcolor { ganttRed, ganttGreen, ganttOrange, ganttBlue, ganttPurple };
        protected void Page_Load(object sender, EventArgs e)
        {

            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            str_First_Day = DateTime.Now.ToString("yyyy/MM/dd");
            str_Last_Day = DateTime.Now.AddDays(1).ToString("yyyy/MM/dd");

            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                //效能測試用
                DateTime start = DateTime.Now;
                string endtime = "1990/01/01 上午 00:00:00";
                DateTime end = DateTime.Parse(endtime);
                string url = System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0];
                HtmlUtil.Time_Look(acc, url, start, end, Request.ServerVariables["HTTP_USER_AGENT"]);
                Refresh_Time = set_time(acc);
                URL_NAME = "Machine_list_info";
                color = HtmlUtil.change_color(acc);
                if (myclass.user_view_check(URL_NAME, acc) == true)
                {
                    if (!IsPostBack)
                        set_page_content();
                }
                else
                    Response.Write("<script>alert('您無法瀏覽此頁面 請向該單位主管申請權限!');location.href='../index.aspx';</script>");

                //效能測試
                end = DateTime.Now;
                HtmlUtil.Time_Look(acc, url, start, end, Request.ServerVariables["HTTP_USER_AGENT"]);
            }
            else
                Response.Redirect(myclass.logout_url);


        }
        private void set_page_content()
        {
            show_checkbox();
            Read_Data();
            Get_MachType_List();
            Mach_Info_List("");

        }
        //fuction         
        public void Read_Data(string machgroup = "")
        {
            if (WebUtils.GetAppSettings("show_CNCgantt") == "1")
            {
                show_gantt_image = "<li role=\"presentation\" class=\"\" style=\"box-shadow: 3px 3px 9px gray;\"><a href=\"#tab_content3\" role=\"tab\" id=\"profile-tab2\" onclick=\"gantt_show()\" data-toggle=\"tab\" aria-expanded=\"false\">排程清單</a></li>";
                show_Gantt();
            }
            string condition = "";
            if(ok.ToLower() == "false")
            {
                string acc_power = HtmlUtil.Search_acc_Column(acc, "Belong_Factory");

                if (acc_power == "" || acc_power == "All" || acc_power == "全部")
                    condition = "";
                else
                    condition = $" where area_name = '{acc_power}' ";
            }


            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            ls_data.Clear();
            if (b_Page_Load || DropDownList_MachType.Text == "--Select--")//|| DropDownList_MachGroup.Text == "--Select--")
            {
                try
                {
                    DataRow SQL_row = DataTableUtils.DataTable_GetRowHeader("mach_type_group").NewRow();
                    SQL_row["read_status"] = "False";
                    DataTableUtils.Update_DataRow("mach_type_group", "read_status = 'True'", SQL_row);
                    is_ok = DataTableUtils.Update_DataRow("mach_type_group", "read_status = 'True'", SQL_row);
                    foreach (DataRow row in DataTableUtils.GetDataTable($"select mach_name from machine_info {condition}").Rows)
                        ls_data.Add(row.ItemArray[0].ToString());
                }
                catch
                {
                    Read_Data();
                }

            }
            else
            {
                if (machgroup != "不存在")
                    ls_data = DataTableUtils.GetDataTable("select mach_name from mach_group where group_name = '" + machgroup + "'").Rows[0].ItemArray[0].ToString().Split(',').ToList();
                else
                    ls_data = null;
            }

            if (ls_data != null && ls_data.Count != 0)
            {
                mach_count = ls_data.Count;
                for (int iIndex = 0; iIndex < ls_data.Count; iIndex++)
                {
                    string devname = ls_data[iIndex];
                    dt_data = Web_Data.Get_MachInfo(ls_data[iIndex]);
                    dev_name = ls_data[iIndex];
                    if (dt_data != null)
                    {
                        string CheckStaff, WorkStaff, MachName, CustomName, ManuId, ProductName, ProductNumber, CraftName, CountTotal, CountToday, ExpCountToday, CountTodayRate, FinishTime, StatusBar, OperRate, MachStatus, AlarmMesg, ProgramRun, ProgramMain;
                        CheckStaff = Web_Data.Get_CheckStaff(dt_data);//Y校機人員2
                        WorkStaff = Web_Data.Get_WorkStaff(dt_data);//Y加工人員3
                        MachName = Web_Data.Get_MachName(dt_data, ls_data[iIndex]);//設備名稱
                        CustomName = Web_Data.Get_CustomName(dt_data);//Y客戶名稱5
                        ManuId = Web_Data.Get_ManuID(dt_data);//Y製令單號6
                        ProductName = Web_Data.Get_ProductName(dt_data);//Y產品名稱7
                        ProductNumber = Web_Data.Get_ProductNumber(dt_data);//Y產品編號8
                        CraftName = Web_Data.Get_CraftName(dt_data);//Y工藝名稱9
                        CountTotal = Web_Data.Get_CountTotal(dt_data);//Y生產總數11             //註解
                        CountToday = Web_Data.Get_CountToday(dt_data);//Y生產件數(當日)12         //註解
                        ExpCountToday = Web_Data.Get_ExpCountToday(dt_data);//Y目標件數(當日)13
                        CountTodayRate = Web_Data.Get_CountTodayRate(dt_data);//Y生產進度(當日)14       //註解
                        FinishTime = Web_Data.Get_FinishTime(dt_data);//ok                 //註解  
                        StatusBar = ls_data[iIndex];//狀態Bar
                        OperRate = Web_Data.Get_Operate_Rate(dt_data, MachName);
                        MachStatus = Web_Data.Get_MachStatus(dt_data, ls_data[iIndex]);
                        //    str_status = MachStatus;
                        AlarmMesg = Web_Data.Get_AlarmMesg(dt_data);//Y異警資訊16               //註解
                        ProgramRun = Web_Data.Get_ProgramRun(dt_data, ls_data[iIndex]);//主程式                 //註解     

                        //20201201新增
                        string acts = Web_Data.Get_Information(dt_data, "acts");//主軸轉速
                        string spindleload = Web_Data.Get_Information(dt_data, "spindleload");//主軸負載
                        string spindlespeed = Web_Data.Get_Information(dt_data, "spindlespeed");//主軸速度
                        string spindletemp = Web_Data.Get_Information(dt_data, "spindletemp");//主軸溫度
                        string prog_main = Web_Data.Get_Information(dt_data, "prog_main"); ;//主程式
                        string prog_main_cmd = Web_Data.Get_Information(dt_data, "prog_main_cmd");//主程式註解
                        string prog_run_cmd = Web_Data.Get_Information(dt_data, "prog_run_cmd");//運行程式註解
                        string overrides = Web_Data.Get_Information(dt_data, "override");//進給率
                        string run_time = Web_Data.Get_Information(dt_data, "run_time");//運轉時間
                        string cut_time = Web_Data.Get_Information(dt_data, "cut_time");//切削時間
                        string poweron_time = Web_Data.Get_Information(dt_data, "poweron_time");//通電時間
                        try
                        {
                            order_num = DataTableUtils.toString(dt_data.Rows[0]["order_number"]);
                        }
                        catch
                        {
                            order_num = "0";
                        }

                        int count = 0;
                        string sqlcmd = $"select * from aps_list_info where order_number > {order_num} and mach_name = '{MachName}'";
                        DataTable dt_count = DataTableUtils.GetDataTable(sqlcmd);
                        try
                        {
                            count = dt_count.Rows.Count;
                        }
                        catch
                        {
                            count = 0;
                        }

                        //Dictionary<string, string> keyValues = new Dictionary<string, string>();
                        //keyValues.Add("mach_name", Web_Data.Get_MachName(dt_data, ls_data[iIndex]));
                        //keyValues.Add("check_staff", Web_Data.Get_CheckStaff(dt_data));
                        //keyValues.Add("work_staff", Web_Data.Get_WorkStaff(dt_data));
                        //keyValues.Add("mach_status", Web_Data.Get_MachStatus(dt_data, ls_data[iIndex]));
                        //if (Web_Data.Get_Operate_Rate(dt_data, ls_data[iIndex]) != "非數值")
                        //    keyValues.Add("operate_rate", Math.Round(DataTableUtils.toDouble(Web_Data.Get_Operate_Rate(dt_data, ls_data[iIndex])) / mach_count, 1, MidpointRounding.AwayFromZero) + "%");
                        //else
                        //    keyValues.Add("operate_rate", Math.Round(DataTableUtils.toDouble("0") / mach_count, 1, MidpointRounding.AwayFromZero) + "%");
                        //keyValues.Add("status_bar", ls_data[iIndex]);
                        //keyValues.Add("manu_id", Web_Data.Get_ManuID(dt_data));
                        //keyValues.Add("custom_name", Web_Data.Get_CustomName(dt_data));
                        //keyValues.Add("product_name", Web_Data.Get_ProductName(dt_data));
                        //keyValues.Add("product_number", Web_Data.Get_ProductNumber(dt_data));
                        //keyValues.Add("program_run", Web_Data.Get_ProgramRun(dt_data, ls_data[iIndex]));
                        //keyValues.Add("finish_time", CNCUtils.date_Substring(Web_Data.Get_FinishTime(dt_data)));
                        //keyValues.Add("count_today_rate", Math.Round(DataTableUtils.toDouble(Web_Data.Get_CountTodayRate(dt_data)) / mach_count, 1, MidpointRounding.AwayFromZero) + "%" + " %  (" + DataTableUtils.toInt(Web_Data.Get_CountToday(dt_data)) + "/" + DataTableUtils.toInt(Web_Data.Get_ExpCountToday(dt_data)) + ")");
                        //keyValues.Add("alarm_mesg", Web_Data.Get_AlarmMesg(dt_data));
                        //keyValues.Add("craft_name", Web_Data.Get_CraftName(dt_data));
                        //keyValues.Add("acts", Web_Data.Get_Information(dt_data, "acts"));
                        //keyValues.Add("spindleload", Web_Data.Get_Information(dt_data, "spindleload"));
                        //keyValues.Add("spindlespeed", Web_Data.Get_Information(dt_data, "spindlespeed"));
                        //keyValues.Add("spindletemp", Web_Data.Get_Information(dt_data, "spindletemp"));
                        //keyValues.Add("prog_main", Web_Data.Get_Information(dt_data, "prog_main"));
                        //keyValues.Add("prog_main_cmd", Web_Data.Get_Information(dt_data, "prog_main_cmd"));
                        //keyValues.Add("prog_run_cmd", Web_Data.Get_Information(dt_data, "prog_run_cmd"));
                        //keyValues.Add("override", Web_Data.Get_Information(dt_data, "override"));
                        //keyValues.Add("run_time", Web_Data.Get_Information(dt_data, "run_time"));
                        //keyValues.Add("cut_time", Web_Data.Get_Information(dt_data, "cut_time"));
                        //keyValues.Add("poweron_time", Web_Data.Get_Information(dt_data, "poweron_time"));
                        //List<string> list = new List<string>();
                        //if (DataTableUtils.toString(dt_data.Rows[0]["order_number"]) == "0" || DataTableUtils.toString(dt_data.Rows[0]["order_number"]) == "" || count == 0)
                        //{
                        //    list.Add("disabled=\"disabled\" value=\"已無工程\"");
                        //    list.Add("btn btn-danger");
                        //}
                        //else
                        //{
                        //    list.Add("value=\"下個工藝\"");
                        //    list.Add("btn btn-primary");
                        //}
                        //keyValues.Add("next_button","<input type=\"button\" class=\""+list[1]+"\" onclick=Next_Craft('" + Web_Data.Get_MachName(dt_data, ls_data[iIndex]) + "','" + DataTableUtils.toString(dt_data.Rows[0]["order_number"]) + "')  " + list[0] + " >");


                        設定圖塊(MachName, CheckStaff, WorkStaff, MachStatus, OperRate, StatusBar, ManuId, CustomName, ProductName, ProductNumber, ProgramRun, CountTotal, ExpCountToday, FinishTime, "0", CountTodayRate, AlarmMesg, CountToday, CraftName, acts, spindleload, spindlespeed, spindletemp, prog_main, prog_main_cmd, prog_run_cmd, overrides, run_time, cut_time, poweron_time);
                        設定表格(MachName, CheckStaff, WorkStaff, MachStatus, OperRate, StatusBar, ManuId, CustomName, ProductName, ProductNumber, ProgramRun, CountTotal, ExpCountToday, FinishTime, "0", CountTodayRate, AlarmMesg, CountToday, CraftName, acts, spindleload, spindlespeed, spindletemp, prog_main, prog_main_cmd, prog_run_cmd, overrides, run_time, cut_time, poweron_time, order_num, count);

                        if (Check_Status(MachStatus) == "OPERATE") Panel_StatusValue[0] += 1;
                        else if (Check_Status(MachStatus) == "STOP") Panel_StatusValue[1] += 1;
                        else if (Check_Status(MachStatus) == "EMERGENCY") Panel_StatusValue[2] += 1;
                        else if (Check_Status(MachStatus) == "DISCONNECT") Panel_StatusValue[3] += 1;

                        if (iIndex < ls_data.Count - 1) str_Dev_Status += MachStatus + ", ";
                        else str_Dev_Status += MachStatus;
                    }
                }
                if (!b_Page_Load)//要讓web service判斷哪些設備用
                {
                    is_ok = DataTableUtils.Delete_Record("mach_type_group", "");//先刪

                    dt_data = DataTableUtils.GetDataTable("mach_group", "group_name = '" + machgroup + "'");
                    string group_machname = dt_data.Rows[0]["mach_name"].ToString();
                    string group_machshowname = dt_data.Rows[0]["mach_name"].ToString();

                    dt_data = DataTableUtils.GetDataTable("mach_type_group", "");
                    DataRow SQL_row = null;
                    SQL_row = dt_data.NewRow();
                    SQL_row["mach_type"] = DropDownList_MachType.SelectedItem.Text;
                    SQL_row["mach_group"] = machgroup;
                    SQL_row["mach_name"] = group_machname;
                    SQL_row["mach_show_name"] = group_machshowname;
                    SQL_row["read_status"] = "True";
                    is_ok = DataTableUtils.Insert_DataRow("mach_type_group", SQL_row);
                }
            }
        }
        public string Check_Status(string status)
        {
            if (status == "ALARM" || status == "EMERGENCY") status = "EMERGENCY";
            else if (status == "OPERATE" || status == "MANUAL" || status == "WARMUP") status = "OPERATE";
            else if (status == "STOP" || status == "SUSPEND") status = "STOP"; //|| status == "SUSPEND" 從啟動改暫停
            else if (status == "DISCONNECT") status = "DISCONNECT";
            return status;
        }
        private void 設定表格(string 設備名稱, string 校機人員, string 加工人員, string 設備狀態, string 設備稼動, string 設備稼動_長條圖, string 製令單號, string 客戶名稱, string 產品名稱, string 料件編號, string 加工程式, string 生產件數, string 預計生產件數, string 預計完工時間, string 問題回報, string 生產進度, string 異警資訊, string 今日生產件數, string 工藝名稱, string 主軸轉速, string 主軸負載, string 主軸速度, string 主軸溫度, string 主程式, string 主程式註解, string 運行程式註解, string 進給率, string 運轉時間, string 切削時間, string 通電時間, string 工藝, int next_count = 0)
        {
            string 設備狀態_色彩 = cNC_Class.mach_status_Color(Check_Status(設備狀態));
            設備狀態 = cNC_Class.mach_status_EN2CH(Check_Status(設備狀態));

            if (工藝 == "0" || 工藝 == "" || next_count == 0)
                工藝 = "disabled=\"disabled\" value=\"已無工程\"";
            else
                工藝 = "value=\"下個工藝\"";

            //找出可以被選取的欄位
            if (th == "")
                th = set_column();
            tr += "<tr style='color:white; background-color:" + 設備狀態_色彩 + ";' id='" + 設備名稱 + "'>";
            string old_name = 設備名稱;
            //這部分由於空白會造成換行的情況，因此做此措施
            string[] str = CNCUtils.MachName_translation(設備名稱).Split(' ');
            if (str.Length > 1)
            {
                for (int i = 0; i < str.Length; i++)
                {
                    if (i == 0)
                        設備名稱 = str[i];
                    else
                        設備名稱 += "&nbsp" + str[i];
                }

            }

            else
                設備名稱 = str[0];
            加工程式 = 加工程式.Split('/')[加工程式.Split('/').Length - 1];
            主程式 = 主程式.Split('/')[主程式.Split('/').Length - 1];

            if (設備狀態 == "閒置")
                設備狀態 = "待機";

            switch (設備狀態)
            {
                case "運轉":
                    run++;
                    break;
                case "待機":
                    rest++;
                    break;
                case "警報":
                    alert++;
                    break;
                case "離線":
                    noline++;
                    break;
            }
            percent += Math.Round(DataTableUtils.toDouble(設備稼動) / mach_count, 1, MidpointRounding.AwayFromZero);
            progress += Math.Round(DataTableUtils.toDouble(生產進度) / mach_count, 1, MidpointRounding.AwayFromZero);
            tr += show_table("mach_name", 設備名稱);
            tr += show_table("check_staff", 校機人員);
            tr += show_table("work_staff", 加工人員);
            tr += show_table("mach_status", 設備狀態);
            tr += show_table("operate_rate", 設備稼動 + " %");
            tr += show_table("manu_id", 製令單號);
            tr += show_table("custom_name", 客戶名稱);
            tr += show_table("product_name", 產品名稱);
            tr += show_table("product_number", 料件編號);
            tr += show_table("craft_name", 工藝名稱);
            tr += show_table("count_today_rate", 生產進度 + " %  (" + DataTableUtils.toInt(今日生產件數) + "/" + DataTableUtils.toInt(預計生產件數) + ")");
            tr += show_table("finish_time", CNCUtils.date_Substring(預計完工時間));
            tr += show_table("acts", 主軸轉速);
            tr += show_table("spindleload", 主軸負載);
            tr += show_table("spindlespeed", 主軸速度);
            tr += show_table("spindletemp", 主軸溫度);
            tr += show_table("prog_main", 主程式);
            tr += show_table("prog_main_cmd", 主程式註解);
            tr += show_table("program_run", 加工程式);
            tr += show_table("prog_run_cmd", 運行程式註解);
            tr += show_table("override", 進給率);
            tr += show_table("run_time", 運轉時間);
            tr += show_table("cut_time", 切削時間);
            tr += show_table("poweron_time", 通電時間);
            tr += show_table("alarm_mesg", 異警資訊);
            if (工藝 != "value=\"下個工藝\"")
                tr += show_table("next_button", "<input type=\"button\" class=\"btn btn-danger\" onclick=Next_Craft('" + old_name + "','" + order_num + "')  " + 工藝 + " >");//按鈕，進入下一個工序用
            else
                tr += show_table("next_button", "<input type=\"button\" class=\"btn btn-primary\" onclick=Next_Craft('" + old_name + "','" + order_num + "')  " + 工藝 + " >");//按鈕，進入下一個工序用

            tr += "</tr>";
        }
        //設定表格欄位
        private string set_column()
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_outside);
            string column = "";
            //有資料的情況，抓有資料的
            DataTable dt = DataTableUtils.GetDataTable("select info_chinese from realtime_info left join show_column on show_column.Column_Name = realtime_info.info_name where show_status='True' and show_check='Y' and Allow = 'True' and Account = '" + acc + "'");
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow row in dt.Rows)
                {
                    if (DataTableUtils.toString(row["info_chinese"]) == "生產進度")
                        column += "<th align=\"center\" style=\"vertical-align:middle;\">生產進度(目前/預計)</th>";
                    else
                        column += "<th align=\"center\" style=\"vertical-align:middle;\">" + row["info_chinese"] + "</th>";
                }
            }
            //沒有資料的情況下
            else if (dt != null && dt.Rows.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_outside);
                dt = DataTableUtils.DataTable_GetTable("select info_chinese from realtime_info where show_status='True' and show_check='Y'");
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        if (DataTableUtils.toString(row["info_chinese"]) == "生產進度")
                            column += "<th align=\"center\" style=\"vertical-align:middle;\">生產進度(目前/預計)</th>";
                        else
                            column += "<th align=\"center\" style=\"vertical-align:middle;\">" + row["info_chinese"] + "</th>";
                    }
                }
            }
            return column;
        }
        public string show_table(string column, string value)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            DataTable dt = DataTableUtils.GetDataTable("select * from show_column where Account = '" + acc + "'");
            string td_content = "";
            //有資料存在的情況下
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            dt_data = DataTableUtils.GetDataTable("select * from realtime_info left join show_column on realtime_info.info_name = show_column.Column_Name where Account = '" + acc + "' and Allow = 'True' and realtime_info.info_name = '" + column + "'");
            if (dt_data != null && dt_data.Rows.Count > 0)
            {
                if (dt_data.Rows[0]["Allow"].ToString() == "True")
                    return "<td align=\"center\" style=\"vertical-align:middle;\">" + value + "</td>";
                else
                    return "";
            }
            //沒有資料存在的情況下
            else if (dt_data != null && dt != null && dt_data.Rows.Count == 0 && dt.Rows.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                dt_data = DataTableUtils.GetDataTable("select show_status,show_check from realtime_info where info_name = '" + column + "'");
                if (dt_data != null && dt_data.Rows.Count > 0)
                {
                    if (dt_data.Rows[0]["show_status"].ToString() == "True" && dt_data.Rows[0]["show_check"].ToString() == "Y")
                        td_content = "<td align=\"center\" style=\"vertical-align:middle;\" >" + value + "</td>";
                }
                else if (dt_data == null)
                    return show_table(column, value);
                return td_content;
            }
            else if (dt_data == null || dt == null)
                return show_table(column, value);
            else
                return td_content;
        }
        private void 設定圖塊(string 設備名稱, string 校機人員, string 加工人員, string 設備狀態_燈號, string 設備稼動, string 設備稼動_長條圖, string 製令單號, string 客戶名稱, string 產品名稱, string 料件編號, string 加工程式, string 生產件數, string 預計生產件數, string 預計完工時間, string 問題回報, string 生產進度, string 異警資訊, string 今日生產件數, string 工藝名稱, string 主軸轉速, string 主軸負載, string 主軸速度, string 主軸溫度, string 主程式, string 主程式註解, string 運行程式註解, string 進給率, string 運轉時間, string 切削時間, string 通電時間)
        {
            string machine = "mach" + mach_count;

            mach_count++;
            string 設備狀態 = cNC_Class.mach_status_EN2CH(設備狀態_燈號);
            string 字體顏色 = cNC_Class.mach_font_Color(設備狀態);
            string 背景顏色 = cNC_Class.mach_background_Color(設備狀態);

            switch (設備狀態)
            {
                case "閒置":
                    設備狀態 = "待機";
                    break;
                case "暫停":
                    設備狀態 = "待機";
                    break;
            }
            string mach = 設備名稱;
            area += "<div id='chart_" + 設備名稱 + "' class='col-md-6 col-sm-12 col-xs-12' >\n";
            area += "   <div class='dashboard_graph x_panel'  style=\" border: 2px solid #1f1f1f \" >\n";
            area += "       <div class='col-md-12 col-sm-12 col-xs-12' style='padding:0px 0px;'>\n";
            string[] str = CNCUtils.MachName_translation(設備名稱).Split(' ');
            if (str.Length > 1)
            {
                for (int i = 0; i < str.Length; i++)
                {
                    if (i == 0)
                        設備名稱 = str[i];
                    else
                        設備名稱 += "&nbsp" + str[i];
                }
            }
            else
                設備名稱 = str[0];
            area += "           <div class='left col-md-12 col-sm-12 col-xs-12' style='font-size:19px'>\n";
            area += "               <div class ='col-md-12 col-sm-12 col-xs-12' >\n";
            area += "                   <div class ='col-md-4 col-sm-12 col-xs-12' style='text-align:center;'>\n";
            //area += $"                     <img onclick=\"change_showview('{mach}')\" id=\"{mach}_img\" name=\"{mach}_img\" class='img-rounded' src='/pages/dp_CNC/CNC_Image/" + mach + ".jpg' alt='...' style='width:100%;height:240px;align-items:center;'>";
            //area += CNCUtils.Have_CameraMachine(mach);

            area += "            <button onclick=\"gotocamera('" + CNCUtils.Have_CameraLink(mach) + "')\" type=\"button\" id=\"exportChart\" title=\"前往攝影機畫面\" style=\"width:100%;margin-top:6px; text-align:center; text-valign:center;\">";
            area += "<img src=\"../../assets/images/camera.jpg\" style=\"width:28px; height: 28px;\">";
            area += "</button>";
            area += "                     <img  class='img-rounded' src='/pages/dp_CNC/CNC_Image/" + mach + ".jpg' alt='...' style='width:100%;height:200px;align-items:center;'>";
            area += "                   </div>\n";
            area += "                   <div class ='col-md-8 col-sm-12 col-xs-12'>\n";

            area += Image_typesetting("設備狀態", "               <div id = 'ma_canvas_status" + mach + "' class='_mdTitle' style='font-size:20px;text-align:center;background-color:" + 背景顏色 + ";color:" + 字體顏色 + ";'>" + 設備狀態 + "</div>", "1");
            area += Image_typesetting("mach_name", 設備名稱, "1");
            area += Image_typesetting("count_today_rate", 生產進度 + " % " + "(" + 今日生產件數 + "/" + 預計生產件數 + ")", "1");
            area += Image_typesetting("operate_rate", 設備稼動 + " % ", "1");
            try
            {
                area += Image_typesetting("finish_time", 預計完工時間.Substring(0, 11), "1");
            }
            catch
            {
                area += Image_typesetting("finish_time", 預計完工時間, "1");
            }
            area += "                   </div>\n";
            area += "               </div>\n";
            area += "           <div class='col-xs-12 col-sm-12'>\n";
            area += 顯示資訊("status_bar", 設備稼動_長條圖);
            area += "           </div>\n";

            area += "               <div class ='col-md-9 col-sm-9 col-xs-8'>\n";
            area += "                   <div class ='col-md-12 col-sm-12 col-xs-9'>\n";
            area += $"                      <a data-toggle=\"collapse\" data-parent=\"#accordion\"  href=\"#{machine}\" onclick=\"change_icon('{machine}1','{machine}2')\"  >\n";
            area += "                           <div class ='col-md-12 col-sm-12 col-xs-12' style='background:#8D9BE3;text-align:center' >\n";
            area += $"                              <b id=\"{machine}2\"  style=\"color:black\" >展開詳細資料   </b>  <i id=\"{machine}1\"  class=\"fa fa-chevron-circle-down\" style=\"color:black;width:3%;font-size: 1.4em;\"></i>\n";
            area += $"                          </div>\n";
            area += "                       </a>\n";
            area += $"                  </div>\n";
            area += $"               </div>\n";
            area += "               <div class ='col-md-3 col-sm- col-xs-4'>\n";
            area += "                   <button type=\"button\" class=\"btn btn-info btn-sm ButtonStyle\" style='width:93%;position:absolute; right:1px;text-align:center;background-color:#8D9BE3;color:black' onclick=jump('" + WebUtils.UrlStringEncode("machine=" + mach) + "') ><b>問題回報</b></button>";
            area += $"               </div>\n";



            //area += $"<a data-toggle=\"collapse\" data-parent=\"#accordion\"  href=\"#{machine}\" onclick=\"change_icon('{machine}1','{machine}2')\"  >\n";
            //area += "               <div class ='col-md-12 col-sm-12 col-xs-12' style='background:#8D9BE3;text-align:center' >\n";
            //area += $"<b id=\"{machine}2\"  style=\"color:black\" >展開詳細資料   </b>  <i id=\"{machine}1\"  class=\"fa fa-chevron-circle-down\" style=\"color:black;width:3%;font-size: 1.4em;\"></i>\n";
            //area += $"               </div>\n";
            //area += "</a>\n";



            area += $" <div id = \"{machine}\" class=\"panel-collapse collapse  \">\n";
            area += "<div class=\"panel-body\">\n";
            加工程式 = 加工程式.Split('/')[加工程式.Split('/').Length - 1];

            area += "               <div class ='col-md-6 col-sm-6 col-xs-12'>\n";
            area += Image_typesetting("acts", 主軸轉速, "2");
            area += Image_typesetting("spindlespeed", 主軸速度, "2");
            area += Image_typesetting("prog_main", 主程式, "2");
            area += Image_typesetting("program_run", 加工程式, "2");
            area += Image_typesetting("override", 進給率, "2");
            area += Image_typesetting("cut_time", 切削時間, "2");
            area += Image_typesetting("work_staff", 加工人員, "2");
            area += Image_typesetting("manu_id", 製令單號, "2");
            area += Image_typesetting("product_number", 料件編號, "2");
            area += Image_typesetting("craft_name", 工藝名稱, "2");
            //area += Image_typesetting("manu_id", 製令單號, "2");
            //area += Image_typesetting("product_number", 料件編號, "2");
            //area += Image_typesetting("craft_name", 工藝名稱, "2");
            //area += Image_typesetting("work_staff", 加工人員, "2");
            area += "               </div>\n";

            area += "               <div class ='col-md-6 col-sm-6 col-xs-12'>\n";
            area += Image_typesetting("spindleload", 主軸負載, "2");
            area += Image_typesetting("spindletemp", 主軸溫度, "2");
            area += Image_typesetting("prog_main_cmd", 主程式註解, "2");
            area += Image_typesetting("prog_run_cmd", 運行程式註解, "2");
            area += Image_typesetting("run_time", 運轉時間, "2");
            area += Image_typesetting("poweron_time", 通電時間, "2");
            area += Image_typesetting("check_staff", 校機人員, "2");
            area += Image_typesetting("custom_name", 客戶名稱, "2");
            area += Image_typesetting("product_name", 產品名稱, "2");
            //area += Image_typesetting("custom_name", 客戶名稱, "2");
            //area += Image_typesetting("product_name", 產品名稱, "2");
            //area += Image_typesetting("program_run", 加工程式, "2");
            //area += Image_typesetting("check_staff", 校機人員, "2");
            area += "               </div>\n";
            area += "               <div class ='col-md-12 col-sm-12 col-xs-12'>\n";
            area += Image_typesetting("alarm_mesg", 異警資訊, "3");
            area += "               </div>\n";


            area += "           </div>\n";
            area += "       </div>\n";
            area += "           </div>\n";
            area += "       </div>\n";
            area += "   </div>\n";
            area += "</div>\n";
            //網頁開啟後兩秒,顯示狀態bar
            js_code += "mTimer_status = setTimeout(function () { draw_Axial('" + 設備稼動_長條圖 + "'); }, 2000);\n";

        }
        public string 顯示資訊(string Info, string Value, string status = "")
        {
            dt_data = DataTableUtils.GetDataTable("select show_status from realtime_info where info_name = '" + Info + "'");
            string Str = "";
            if (dt_data != null && dt_data.Rows.Count != 0)
            {
                if (Info == "operate_rate" || Info == "count_today_rate" && dt_data.Rows[0]["show_status"].ToString() == "True")
                {
                    Info = CNCUtils.namechange(Info);
                    if (str_status == "DISCONNECT" || Value == "--")
                        Str += "                      <div><p><strong>" + Info + "：</strong><span>" + Value + "</span></p></div>\n";
                    else
                        Str += "                      <div><p><strong>" + Info + "：</strong><span>" + Value + " %" + "</span></p></div>\n";
                }
                else if (Info == "status_bar" && dt_data.Rows[0]["show_status"].ToString() == "True")
                {
                    Str += "           <div id = 'ma_div_" + Value + "'>";
                    Str += "<canvas id = 'ma_canvas_" + Value + "' width = '500' height = '40'></canvas>";
                    Str += "</div>";
                }
                else if (Info == "status_bar" && dt_data.Rows[0]["show_status"].ToString() == "False")
                {

                    Str += "           <div style='display: none'><div id = 'ma_div_" + Value + "'></div>";
                    Str += "               <div style='display: none'><canvas id = 'ma_canvas_" + Value + "' width = '40' height = '500'></canvas></div></div>";
                }
                else if (dt_data.Rows[0]["show_status"].ToString() == "True")
                {
                    Info = CNCUtils.namechange(Info);
                    Str += "                      <div><p><strong>" + Info + "：</strong><span>" + Value + "<span></p></div>\n";
                }
                else
                {
                    Info = CNCUtils.namechange(Info);
                    Str += "                      <div style='display: none'><p><strong>" + Info + "：</strong><span>" + Value + "<span></p></div>\n";

                }
            }
            return Str;
        }
        public string Image_typesetting(string Info, string value, string type)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = "select * from realtime_info where info_name = '" + Info + "'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            if (dt != null && dt.Rows.Count > 0)
                Info = DataTableUtils.toString(dt.Rows[0]["info_chinese"]);
            string Image = "";
            //設備狀態、設備名稱、設備稼動率、今日生產進度(今日/預計)、預計完工時間
            if (type == "1")
            {
                Image += "<div class ='col-md-7 col-sm-6 col-xs-6' style='background:#EAEAEA;text-align:center;height:34px;font-size:20px;margin-top: 7px; margin-bottom: 7px;'>\n";
                if (Info != "生產進度")
                    Image += Info + "\n";
                else
                    Image += "生產進度(目前/預計) \n";
                Image += "</div>\n";
                Image += "<div class ='col-md-5 col-sm-6 col-xs-6' style='text-align:center;font-size:20px; margin-top: 7px; margin-bottom: 7px;'>\n";
                if (value == "")
                    value = " <br /> ";
                Image += "<span> " + value + "</span>\n";
                Image += "<hr class=\"_hr2\"/>";
                Image += "</div>\n";
            }
            //客戶名稱、產品名稱、加工程式、校機人員、料件編號、工藝名稱、加工人員、製令單號
            else if (type == "2")
            {
                Image += "<div class ='col-md-4 col-sm-6 col-xs-6' style='background:#EAEAEA;text-align:center;font-size:15px; margin-top: 7px; '>\n";
                Image += Info + "\n";
                Image += "</div>\n";
                Image += "<div class ='col-md-8 col-sm-6 col-xs-6' style='text-align:center;font-size:15px; margin-top: 7px; '>\n";
                if (value == "")
                    value = " <br /> ";
                Image += "<span> " + value + "</span>\n";
                Image += "<hr class=\"_hr2\"/>";
                Image += "</div>\n";
            }
            //異警資訊
            else if (type == "3")
            {
                Image += "<div class ='col-md-2 col-sm-2 col-xs-2' style='background:#EAEAEA;text-align:center;font-size:15px; margin-top: 7px; '>\n";
                Image += Info + "\n";
                Image += "</div>\n";
                Image += "<div class ='col-md-10 col-sm-10 col-xs-10' style='text-align:center;font-size:15px; margin-top: 7px; '>\n";
                if (value == "")
                    value = " <br /> ";
                Image += "<span> " + value + "</span>\n";
                Image += "<hr class=\"_hr2\"/>";
                Image += "</div>\n";
            }
            return Image;
        }
        private void Get_MachType_List()//取type list
        {

            //string acc_power = HtmlUtil.Search_acc_Column(acc, "Belong_Factory");
            string condition = "";
            //if (acc_power == "" || acc_power == "All" || acc_power == "全部")
            //    condition = "";
            //else
            //    condition = $" where type_name='{acc_power}' ";


            DropDownList_MachType.Items.Clear();
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            dt_data = DataTableUtils.GetDataTable($"select type_name from mach_type {condition} ");
            if (dt_data != null && dt_data.Rows.Count != 0)
            {
                DropDownList_MachType.Items.Add("--Select--");
                for (int iIndex = 0; iIndex < dt_data.Rows.Count; iIndex++)
                    DropDownList_MachType.Items.Add(dt_data.Rows[iIndex]["type_name"].ToString());
            }
        }
        public void Mach_Info_List(string MachGroup = "")    //畫status_bar使用
        {
            if (ls_data != null)
                ls_data.Clear();
            string condition = "";
            if(ok.ToLower()== "false")
            {
                string acc_power = HtmlUtil.Search_acc_Column(acc, "Belong_Factory");

                if (acc_power == "" || acc_power == "All" || acc_power == "全部")
                    condition = "";
                else
                    condition = $" where area_name = '{acc_power}' ";
            }

            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            if (MachGroup == "")
            {
                try
                {

                    foreach (DataRow row in DataTableUtils.GetDataTable($"select mach_name from machine_info {condition} ").Rows)
                        ls_data.Add(row.ItemArray[0].ToString());
                }
                catch
                {
                    Mach_Info_List(MachGroup);
                }
            }
            else
            {
                if (MachGroup != "不存在")
                    ls_data = DataTableUtils.GetDataTable("select mach_name from mach_group where group_name = '" + MachGroup + "'").Rows[0].ItemArray[0].ToString().Split(',').ToList();
                else
                    ls_data = null;
            }

            if (ls_data != null && ls_data.Count != 0)
            {
                for (int iIndex = 0; iIndex < ls_data.Count; iIndex++)
                {
                    if (iIndex < ls_data.Count - 1) str_Dev_Name += ls_data[iIndex] + ",";
                    else str_Dev_Name += ls_data[iIndex];
                }
            }
        }
        //顯示個人設定的刷新時間
        private string set_time(string acc)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisErp);
            string sqlcmd = "select * from Users where USER_ACC = '" + acc + "'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            if (dt.Rows.Count > 0)
            {
                if (DataTableUtils.toString(dt.Rows[0]["Set_Time"]) != null && DataTableUtils.toString(dt.Rows[0]["Set_Time"]) != "")
                    return DataTableUtils.toString(dt.Rows[0]["Set_Time"]) + "000";
                else
                    return "60000";
            }
            else
                return "60000";
        }
        //event   
        protected void Select_MachGroupClick(object sender, EventArgs e)    //執行運算
        {
            //先做checkbox的儲存
            save_column(acc);
            Change_Status();
            show_checkbox();

            if (DropDownList_MachType.SelectedItem.Text != "--Select--")//&& DropDownList_MachGroup.SelectedItem.Text != "--Select--")
            {
                ok = "true";
                b_Page_Load = false;
                string sqlcmd = "";
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "select * from mach_type where type_name = '" + DropDownList_MachType.SelectedItem.Text + "' ";
                //if (DropDownList_MachGroup.SelectedItem.Text != "--Select--")
                //    sqlcmd = sqlcmd + " and group_name = '" + DropDownList_MachGroup.SelectedItem.Text + "' ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                if (dt.Rows.Count > 0)
                {
                    if (DropDownList_MachGroup.SelectedItem.Text == "--Select--")
                    {
                        string Group = DataTableUtils.toString(dt.Rows[0]["group_name"]);
                        if (Group != "")
                        {
                            string[] Machine_Group = Group.Split(',');
                            for (int i = 0; i < Machine_Group.Length; i++)
                            {
                                Read_Data(DataTableUtils.toString(Machine_Group[i]));
                                Mach_Info_List(DataTableUtils.toString(Machine_Group[i]));
                            }
                        }
                        else
                        {
                            Read_Data("不存在");
                            Mach_Info_List("不存在");
                        }

                    }
                    else
                    {
                        Read_Data(DropDownList_MachGroup.SelectedItem.Text);
                        Mach_Info_List(DropDownList_MachGroup.SelectedItem.Text);
                    }
                }
            }
            else
                Response.Redirect("Machine_list_info.aspx");
        }
        private void save_column(string acc)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_outside);
            string sqlcmd = "select * from show_column where Account = '" + acc + "'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            if (dt != null && dt.Rows.Count > 0)
            {
            }
            else if (dt != null && dt.Rows.Count == 0)
            {
                DataRow rew = dt.NewRow();
                rew["Column_Name"] = "mach_name";
                rew["Account"] = acc;
                rew["Allow"] = "True";
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                DataTableUtils.Insert_DataRow("show_column", rew);
                for (int i = 0; i < CheckBoxList_cloumn.Items.Count; i++)
                {

                    DataRow row = dt.NewRow();
                    row["Column_Name"] = DataTableUtils.toString(CheckBoxList_cloumn.Items[i].Value);
                    row["Account"] = acc;
                    row["Allow"] = CheckBoxList_cloumn.Items[i].Selected;
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    DataTableUtils.Insert_DataRow("show_column", row);
                }

            }
        }
        //改變checkbox的狀態
        private void Change_Status()
        {


            //先確定有哪些
            for (int i = 0; i < CheckBoxList_cloumn.Items.Count; i++)
            {
                if (CheckBoxList_cloumn.Items[i].Selected == true)
                    list.Add(CheckBoxList_cloumn.Items[i].Value);
            }
            list.Add("mach_name");
            //找到整個DataTable
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = "select* from show_column where Account = '" + acc + "'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            if (dt != null)
            {
                foreach (DataRow row in dt.Rows)
                {
                    DataRow rew = dt.NewRow();
                    rew["id"] = row["id"];
                    if (list.IndexOf(DataTableUtils.toString(row["Column_Name"])) != -1)
                        rew["Allow"] = "True";
                    else
                        rew["Allow"] = "False";
                    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                    bool ok = DataTableUtils.Update_DataRow("show_column", " ID=" + DataTableUtils.toInt(DataTableUtils.toString(row["id"])) + "", rew);
                }
            }

        }
        //cbx select事件//取group list
        protected void DropDownList_MachType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList_MachType.SelectedItem.Text != "--Select--")
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                ls_data.Clear();
                DropDownList_MachGroup.Items.Clear();
                ls_data = DataTableUtils.GetDataTable("select group_name from mach_type where type_name = '" + DropDownList_MachType.SelectedItem.Text + "'").Rows[0].ItemArray[0].ToString().Split(',').ToList();
                DropDownList_MachGroup.Items.Add("--Select--");
                for (int iIndex = 0; iIndex < ls_data.Count; iIndex++)
                    DropDownList_MachGroup.Items.Add(ls_data[iIndex]);
            }
            else
            {
                DropDownList_MachGroup.Items.Clear();
                DropDownList_MachGroup.Items.Add(" ");
            }
        }
        //搜尋下一個工藝，並把他複製過去
        protected void Search_Next_Click(object sender, EventArgs e)
        {
            Page.ClientScript.RegisterStartupScript(Page.GetType(), "message", "<script>alert('" + Web_Data.Next_MachInfo(TextBox_Machine.Text, TextBox_Number.Text) + "');location.href='Machine_list_info.aspx';</script>");
        }
        //顯示checkbox
        private void show_checkbox()
        {
            Calculation_td = "";
            list.Clear();
            CheckBoxList_cloumn.Items.Clear();
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = "select * from realtime_info left join show_column on show_column.Column_Name = realtime_info.info_name where show_check = 'Y' and info_name <> 'mach_name' and Account = '" + acc + "'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            //已經存在過的
            if (dt != null && dt.Rows.Count > 0)
            {
                ListItem item = new ListItem();

                foreach (DataRow row in dt.Rows)
                {
                    item = new ListItem(DataTableUtils.toString(row["info_chinese"]), DataTableUtils.toString(row["info_name"]));
                    item.Selected = Boolean.Parse(DataTableUtils.toString(row["Allow"]).ToLower());
                    CheckBoxList_cloumn.Items.Add(item);
                }
            }
            //沒有存在過的
            else if (dt.Rows.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "select * from realtime_info  where show_check = 'Y' and info_name <> 'mach_name'";
                dt = DataTableUtils.GetDataTable(sqlcmd);

                ListItem item = new ListItem();

                foreach (DataRow row in dt.Rows)
                {
                    item = new ListItem(DataTableUtils.toString(row["info_chinese"]), DataTableUtils.toString(row["info_name"]));
                    item.Selected = Boolean.Parse(DataTableUtils.toString(row["show_status"]).ToLower());
                    CheckBoxList_cloumn.Items.Add(item);
                }
            }
            for (int i = 0; i < CheckBoxList_cloumn.Items.Count; i++)
            {
                if (CheckBoxList_cloumn.Items[i].Selected == true)
                    list.Add(CheckBoxList_cloumn.Items[i].Value);
            }
            list.Add("mach_name");
            show_tdData(list);
        }
        //輸出到前端的JS
        private void show_tdData(List<string> list)
        {
            for (int i = 0; i < list.Count; i++)
            {
                int j = i + 1;
                if (list[i] == "mach_name" || list[i] == "next_button")
                {

                }
                else if (list[i] == "finish_time")
                    Calculation_td += "document.getElementById(Dev_Name).getElementsByTagName(\"td\")[" + j + "].innerText = " + list[i] + ".substring(0, 11);  \n ";
                else if (list[i] == "count_today_rate")
                    Calculation_td += "document.getElementById(Dev_Name).getElementsByTagName(\"td\")[" + j + "].innerText = count_today_rate + ' %  ' + ' (' + check_tdvalue(count_today) + '/' + check_tdvalue(exp_product_count_day) + ')' ;\n ";
                else if (list[i] == "operate_rate")
                    Calculation_td += "document.getElementById(Dev_Name).getElementsByTagName(\"td\")[" + j + "].innerText = " + list[i] + " + ' %' ;\n  ";
                else
                    Calculation_td += "document.getElementById(Dev_Name).getElementsByTagName(\"td\")[" + j + "].innerText = " + list[i] + ";  \n ";
            }

        }

        //顯示甘特圖
        private void show_Gantt()
        {
            string factory = "";
            if(ok.ToLower() == "false")
            {
                string acc_power = HtmlUtil.Search_acc_Column(acc, "Belong_Factory");
                if (acc_power == "" || acc_power == "All" || acc_power == "全部")
                    factory = "";
                else
                    factory = $" and  machine_info.area_name = '{acc_power}' ";

            }
  



            Gantt_Data = "";
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string condition = "";
            string sqlcmd = "";
            DataTable dt = new DataTable();
            if (DropDownList_MachGroup.Items.Count > 0)
            {
                sqlcmd = $"SELECT mach_name FROM mach_group where group_name = '{DropDownList_MachGroup.SelectedItem.Value}'";
                dt = DataTableUtils.GetDataTable(sqlcmd);

                if (dt != null && dt.Rows.Count > 0)
                {
                    List<string> list = new List<string>(DataTableUtils.toString(dt.Rows[0]["mach_name"]).Split(','));

                    for (int i = 0; i < list.Count; i++)
                    {
                        if (i == 0)
                            condition += $" and ( aps_list_info.mach_name = '{list[i]}' ";
                        else
                            condition += $" OR aps_list_info.mach_name = '{list[i]}' ";
                    }
                    condition = condition + " ) ";
                }
                factory = "";
            }

            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            sqlcmd = $"SELECT aps_list_info.mach_name FROM aps_list_info left join machine_info on machine_info.mach_name = aps_list_info.mach_name  where type ='exception' {factory} {condition}";
            dt = DataTableUtils.GetDataTable(sqlcmd);
            foreach (DataRow row in dt.Rows)
            {
                sqlcmd = $"select * from aps_list_info where type ='exception' and mach_name = '{DataTableUtils.toString(row["mach_name"])}'";
                DataTable ds = DataTableUtils.GetDataTable(sqlcmd);
                Gantt_Data += Get_GanttData(ds, CNCUtils.MachName_translation(DataTableUtils.toString(row["mach_name"])));
            }
        }
        private string Get_GanttData(DataTable dt, string machine)
        {
            int i = 0;
            string gantt_value = "";
            gantt_value += "{";
            gantt_value += "name:'" + machine + "',";
            gantt_value += "desc:'',";
            gantt_value += "values:[";

            foreach (DataRow row in dt.Rows)
            {
                //  gantt_value += "{ from:'/Date(" + from + ")/', to:'/Date(" + to + ")/',  label:'" + label + "',     customClass: \"" + customclass.ToString() + "\"," + information + "},";

                gantt_value += "{ from:'/Date(" + ShareFunction.GetTimeStamp(ShareFunction.StrToDate(DataTableUtils.toString(row["start_time"]))) + ")/', " +
                               "  to:'/Date(" + ShareFunction.GetTimeStamp(ShareFunction.StrToDate(DataTableUtils.toString(row["end_time"]))) + ")/',      " +
                               "  customClass: \"" + Enum.GetName(typeof(classcolor), i % 5) + "\"," +
                               "  desc: \"<b>設備名稱：" + machine + "</b> <br> " +
                               "          <b>製令單號：" + DataTableUtils.toString(row["manu_id"]).Replace(@"""", "") + "</b> <br>" +
                               "          <b>客戶名稱：" + DataTableUtils.toString(row["custom_name"]).Replace(@"""", "") + "</b> <br>" +
                               "          <b>料件編號：" + DataTableUtils.toString(row["product_number"]).Replace(@"""", "") + "</b> <br>" +
                               "          <b>產品名稱：" + DataTableUtils.toString(row["product_name"]).Replace(@"""", "") + "</b> <br> " +
                               "          <b>工藝名稱：" + DataTableUtils.toString(row["craft_name"]).Replace(@"""", "") + "</b> <br>" +
                               "          <b>預計今日生產數量：" + DataTableUtils.toString(row["exp_product_count_day"]).Replace(@"""", "") + "</b> <br>" +
                               "          <b>開始時間：" + ShareFunction.StrToDate(DataTableUtils.toString(row["start_time"])) + "</b> <br>" +
                               "          <b>結束時間：" + ShareFunction.StrToDate(DataTableUtils.toString(row["end_time"])) + "</b> <br>\", " +
                               "},";
                i++;

            }

            gantt_value += "]";
            gantt_value += "},";

            return gantt_value;
        }
    }
}
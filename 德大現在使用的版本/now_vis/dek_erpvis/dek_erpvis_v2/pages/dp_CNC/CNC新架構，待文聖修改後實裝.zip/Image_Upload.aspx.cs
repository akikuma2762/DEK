﻿using dek_erpvis_v2.cls;
using Support;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace dek_erpvis_v2.pages.dp_CNC
{
    public partial class Image_Upload : System.Web.UI.Page
    {
        public string Machine = "";
        string acc = "";
        clsDB_Server clsDB_sw = new clsDB_Server("");
        myclass myclass = new myclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                Machine = Request.QueryString["mach_name"];
            }
            else
                Response.Redirect(myclass.logout_url);

        }

        protected void Button_Upload_Click(object sender, EventArgs e)
        {
            if (FileUpload_Image.FileName != "")
            {
                string path = "D:\\CNC_Image\\";
                string ext = Path.GetExtension(FileUpload_Image.FileName).Replace(".", "");
                Regex regex = new Regex(@"^PNG|JPG|HEIC|HEIF|JPEG$", RegexOptions.IgnoreCase);
                bool ok = regex.IsMatch(ext);
                if (ok == true)
                {
                    FileUpload_Image.SaveAs(path + Machine + ".jpg");
                    Response.Write("<script>alert('上傳完畢!');location.href='../index.aspx';</script>");
                }
            }

        }
    }
}
﻿using dek_erpvis_v2.cls;
using Support;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace dek_erpvis_v2.pages.dp_CNC
{
    public partial class Override_Count : System.Web.UI.Page
    {
        string acc = "";
        string URL_NAME = "";
        public string color = "";
        public string path = "";
        public string th = "";
        public string tr = "";
        myclass myclass = new myclass();
        protected void Page_Load(object sender, EventArgs e)
        {
            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                URL_NAME = "Override_Count";
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                color = HtmlUtil.change_color(acc);
                if (myclass.user_view_check(URL_NAME, acc) == true )
                {
                    if (!IsPostBack)
                    {
                        if (txt_date.Text == "")
                            txt_date.Text = DateTime.Now.ToString("yyyy-MM-dd");
                        load_data();
                    }
                }
                else
                    Response.Write("<script>alert('您無法瀏覽此頁面 請向該單位主管申請權限!');location.href='../index.aspx';</script>");
            }
            else
                Response.Redirect(myclass.logout_url);
        }
        private void load_data()
        {
            Set_Factory();
            Set_Table();
        }
        private void Set_Table()
        {
            string symbol = "";
            string condition = "-";
            string mach = "";
            if (DropDownList_Group.Items.Count > 0 && DropDownList_Group.SelectedItem.Value != "")
            {
                condition = "";
                if (DropDownList_Group.SelectedItem.Value == "--Select--")
                {
                    for (int i = 1; i < DropDownList_Group.Items.Count; i++)
                        mach += DropDownList_Group.Items[i].Value + ",";
                }
                else
                    mach = DropDownList_Group.SelectedItem.Value;


                List<string> list = new List<string>(mach.Split(','));
                for (int i = 0; i < list.Count; i++)
                {
                    if (i == 0)
                        condition += $" and ( override_history_info.mach_name = '{list[i]}' ";
                    else
                        condition += $" OR override_history_info.mach_name = '{list[i]}' ";
                }
                condition = condition + ")";
            }


            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            if (DropDownList_Symbol.SelectedItem.Value == ">")
                symbol = " >= ";
            else
                symbol = " <= ";

            string sqlcmd = $"SELECT mach_show_name as 機台名稱,{DropDownList_Type.SelectedItem.Value} as {DropDownList_Type.SelectedItem.Text},update_time as 開始時間,enddate_time as 結束時間,timespan as 持續時間 FROM override_history_info left join machine_info on override_history_info.mach_name =  machine_info.mach_name where update_time>='{txt_date.Text.Replace("-", "")}000000' and  update_time<='{txt_date.Text.Replace("-", "")}235959' and    CAST({DropDownList_Type.SelectedItem.Value} AS UNSIGNED) {symbol}'{TextBox_Range.Text}' {condition} ";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);


            if (dt != null && dt.Rows.Count > 0)
            {
                string title = "";
                th = HtmlUtil.Set_Table_Title(dt, out title);
                tr = HtmlUtil.Set_Table_Content(dt, title, OverrideCount_callback);
            }
            else
                HtmlUtil.NoData(out th, out tr);
        }
        private string OverrideCount_callback(DataRow row, string field_name)
        {
            string value = "";

            if (field_name == "開始時間" || field_name == "結束時間")
                value = Convert.ToDateTime(DateTime.ParseExact(DataTableUtils.toString(row[field_name]), "yyyyMMddHHmmss.f", System.Globalization.CultureInfo.CurrentCulture)).ToString("yyyy/MM/dd HH:mm:ss");
            else if (field_name == "持續時間")
            {
                int seconds = DataTableUtils.toInt(DataTableUtils.toString(row[field_name]).Split('.')[0]);
                var timespan = TimeSpan.FromSeconds(seconds);
                string day = "";
                if (timespan.ToString("%d") != "0")
                    day = timespan.ToString("%d") + " 天  ";
                value = day + timespan.ToString(@"hh\:mm\:ss");
            }

            if (value == "")
                return "";
            else
                return "<td>" + value + "</td>";
        }
        private void Set_Factory()
        {
            if (DropDownList_factory.Items.Count == 0)
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                string sqlcmd = "select * from mach_type";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
                create_item(dt, DropDownList_factory, "type_name", "group_name",true);
            }
        }
        protected void DropDownList_factory_SelectedIndexChanged(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            string sqlcmd = $"select * from mach_group where group_name = '{DropDownList_factory.SelectedItem.Value}'";
            DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            create_item(dt, DropDownList_Group, "group_name", "mach_name");
        }
        private void create_item(DataTable dt, DropDownList dropDownList, string text, string value, bool special = false)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                ListItem listItem = new ListItem();
                dropDownList.Items.Clear();
                dropDownList.Items.Add("--Select--");
                if (!special)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        listItem = new ListItem(DataTableUtils.toString(row[text]), DataTableUtils.toString(row[value]));
                        dropDownList.Items.Add(listItem);
                    }
                }
                else if (special)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        listItem = new ListItem(DataTableUtils.toString(row[text]), DataTableUtils.toString(row[value]));
                        dropDownList.Items.Add(listItem);
                    }
                    //string acc_power = HtmlUtil.Search_acc_Column(acc, "Belong_Factory");

                    //if (acc_power == "" || acc_power == "All" || acc_power == "全部")
                    //{
                    //    foreach (DataRow row in dt.Rows)
                    //    {
                    //        listItem = new ListItem(DataTableUtils.toString(row[text]), DataTableUtils.toString(row[value]));
                    //        dropDownList.Items.Add(listItem);
                    //    }
                    //}
                    //else
                    //{
                    //    string sqlcmd = $"type_name ='{acc_power}'";
                    //    DataRow[] rows = dt.Select(sqlcmd);

                    //    for (int i = 0; i < rows.Length; i++)
                    //    {
                    //        listItem = new ListItem(DataTableUtils.toString(rows[i][text]), DataTableUtils.toString(rows[i][value]));
                    //        dropDownList.Items.Add(listItem);
                    //    }
                    //}
                }

            }
        }
        protected void button_select_Click(object sender, EventArgs e)
        {
            Set_Table();
        }

    }
}
﻿using System;
using Support;
using dek_erpvis_v2.cls;
using System.Collections.Generic;
using System.Web.UI;
using System.Linq;
using System.Web;
using System.Data;

namespace dek_erpvis_v2.pages.dp_CNC
{
    public partial class Analysis : System.Web.UI.Page
    {
        public string color = "";
        public string timerange = "";
        public DateTime FirstDay = new DateTime();
        public DateTime LastDay = new DateTime();
        public string Type = "";
        public string dev_name = "";
        public string StatusInfo_th = "";
        public string StatusInfo_tr = "";
        public string js_ = "";
        public string js = "";
        public string OperRate_Str = "";            //折線圖
        public string Chart_Percent = "";           //圓餅圖   
        public string StatusRate_Str = "";          //圓餅圖      
        string acc = "", URL_NAME = "";
        public bool b_Page_Load = true;
        public List<string> ls_data = new List<string>();
        public bool is_ok = false;
        public string s_data = null;
        public DataTable dt_data = null;
        CNC_Web_Data Web_Data = new CNC_Web_Data();
        myclass myclass = new myclass();
        CNCUtils cNC_Class = new CNCUtils();
        public string devName;
        //porcess
        protected void Page_Load(object sender, EventArgs e)
        {
            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            FirstDay = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek);  //單位：周
            LastDay = DateTime.Today.AddDays(-(int)DateTime.Today.DayOfWeek + 7).AddSeconds(-1);
            if (LastDay > DateTime.Now) LastDay = DateTime.Now;

            HttpCookie userInfo = Request.Cookies["userInfo"];
            if (userInfo != null)
            {
                acc = DataTableUtils.toString(userInfo["user_ACC"]);
                //效能測試用
                DateTime start = DateTime.Now;
                string endtime = "1990/01/01 上午 00:00:00";
                DateTime end = DateTime.Parse(endtime);
                string url = System.IO.Path.GetFileName(Request.PhysicalPath).Split('.')[0];
                HtmlUtil.Time_Look(acc, url, start, end, Request.ServerVariables["HTTP_USER_AGENT"]);

                URL_NAME = "Analysis_oper_rate";
                color = HtmlUtil.change_color(acc);

                if (textbox_st.Text == "" && textbox_ed.Text == "")
                {
                    int weeknow = Convert.ToInt32(DateTime.Now.DayOfWeek);
                    int daydiff = (-1) * weeknow;

                    //本周第一天
                    textbox_st.Text = DateTime.Now.AddDays(daydiff).ToString("yyyy-MM-dd");

                    daydiff = (7 - weeknow) - 1;
                    //本周最后一天
                    textbox_ed.Text = DateTime.Now.AddDays(daydiff).ToString("yyyy-MM-dd");
                }


                if (myclass.user_view_check(URL_NAME, acc) == true)
                {
                    if (!IsPostBack)
                        set_page_content();
                }
                else
                    Response.Write("<script>alert('您無法瀏覽此頁面 請向該單位主管申請權限!');location.href='../index.aspx';</script>");

                //效能測試
                end = DateTime.Now;
                HtmlUtil.Time_Look(acc, url, start, end, Request.ServerVariables["HTTP_USER_AGENT"]);
            }
            else
                Response.Redirect(myclass.logout_url);
        }
        private void set_page_content()
        {
            Read_Data();
            Get_MachType_List();
        }
        //fuction
        public void Read_Data(string MachGroup = "", string button_name = "")
        {
            if (button_name != "")
                Type = button_name;
            string data_first = "", oper_date = "";
            string[] date_week = { "0", "0", "0", "0", "0", "0", "0" };
            double[] operate_rate_week = { 0, 0, 0, 0, 0, 0, 0 };//紀錄預設當周每日稼動率
            double[] operate_time_week = { 0, 0, 0, 0, 0, 0, 0 };//紀錄預設當周每日總運轉工時
            double[] work_time_week = { 0, 0, 0, 0, 0, 0, 0 };//紀錄預設當周每日總工時
            double[] status_rate_day = { 0, 0, 0, 0 };
            double[] status_time = { 0, 0, 0, 0, 0 };
            double[] status_time_table = { 0, 0, 0, 0, 0 };
            double[] status_rate = { 0, 0, 0, 0 };
            List<string> Status_Rate = new List<string>();
            List<string> Status_Value = new List<string>();

            string condition = "";
            if (HtmlUtil.Search_acc_Column(acc, "Belong_Factory") == "" || HtmlUtil.Search_acc_Column(acc, "Belong_Factory") == "All" || HtmlUtil.Search_acc_Column(acc, "Belong_Factory") == "全部")
                condition = "";
            else
                condition = $" where area_name = '{HtmlUtil.Search_acc_Column(acc, "Belong_Factory")}' ";

            GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);

            ls_data.Clear();
            if (b_Page_Load || DropDownList_MachType.Text == "--Select--")
            {
                DataRow SQL_row = DataTableUtils.DataTable_GetRowHeader("mach_type_group").NewRow();
                SQL_row["read_status"] = "False";
                is_ok = DataTableUtils.Update_DataRow("mach_type_group", "read_status = 'True'", SQL_row);

                foreach (DataRow row in DataTableUtils.GetDataTable($"select mach_name from machine_info {condition} order by _id desc").Rows)
                    ls_data.Add(row.ItemArray[0].ToString());
            }
            else
            {
                if (MachGroup != "不存在")
                    ls_data = DataTableUtils.GetDataTable("select mach_name from mach_group where group_name = '" + MachGroup + "' order by _id desc").Rows[0].ItemArray[0].ToString().Split(',').ToList();
                else
                    ls_data = null;
            }



            if (ls_data != null && ls_data.Count != 0)
            {

                for (int iIndex = 0; iIndex < ls_data.Count; iIndex++)
                {
                    string data_sec = "";
                    FirstDay = DateTime.ParseExact(textbox_st.Text.Replace("-", "") + "000000", "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture);
                    //最後一天若大於當天，則都不顯示
                    if (Int32.Parse(textbox_ed.Text.Replace("-", "")) > Int32.Parse(DateTime.Now.ToString("yyyyMMdd")))
                        LastDay = DateTime.ParseExact(DateTime.Now.ToString("yyyyMMddHHmmss"), "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture);
                    else
                        LastDay = DateTime.ParseExact(textbox_ed.Text.Replace("-", "") + "235959", "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture);

                    Status_Value = Web_Data.Get_Operate_Rate(FirstDay.ToString("yyyyMMdd"), LastDay.ToString("yyyyMMdd"), ls_data[iIndex]);
                    for (int iIndex_1 = 0; iIndex_1 < Status_Value.Count; iIndex_1++)
                    {
                        for (int iIndex_3 = 0; iIndex_3 < status_time.Length; iIndex_3++)
                        {
                            status_time[iIndex_3] += DataTableUtils.toDouble(Status_Value[iIndex_1].Split(':')[1].Split(',')[iIndex_3]);
                            status_time_table[iIndex_3] += DataTableUtils.toDouble(Status_Value[iIndex_1].Split(':')[1].Split(',')[iIndex_3]);
                        }

                        if (b_Page_Load)//第一次
                        {
                            var Mach = ls_data[iIndex];
                            work_time_week[iIndex_1] += DataTableUtils.toDouble(Status_Value[iIndex_1].Split(':')[1].Split(',')[0]);
                            operate_time_week[iIndex_1] += DataTableUtils.toDouble(Status_Value[iIndex_1].Split(':')[1].Split(',')[4]);
                            date_week[iIndex_1] = Status_Value[iIndex_1].Split(':')[0].Substring(6, 2) + "號";
                            if (iIndex == ls_data.Count - 1 && iIndex_1 == Status_Value.Count - 1)
                            {
                                for (int iIndex_2 = 0; iIndex_2 < Status_Value.Count; iIndex_2++)
                                {
                                    operate_rate_week[iIndex_2] = cNC_Class.Math_Round(operate_time_week[iIndex_2], work_time_week[iIndex_2], 2) * 100;
                                    if (double.IsNaN(operate_rate_week[iIndex_2])) operate_rate_week[iIndex_2] = 0;//避免=非數值
                                    data_first += "{ label:'" + date_week[iIndex_2] + "' , y:" + operate_rate_week[iIndex_2] + " },";
                                }
                                OperRate_Str += "{type: 'line',showInLegend: true,name: '平均稼動率',indexLabel: '{y}',dataPoints: [" + data_first + "]},";  //畫第一次折線圖                                
                            }
                            if (iIndex_1 == Status_Value.Count - 1)
                            {
                                status_rate_day[0] = cNC_Class.Math_Round(status_time_table[1], status_time_table[0], 2) * 100;
                                status_rate_day[1] = cNC_Class.Math_Round(status_time_table[2], status_time_table[0], 2) * 100;
                                status_rate_day[2] = cNC_Class.Math_Round(status_time_table[3], status_time_table[0], 2) * 100;
                                status_rate_day[3] = cNC_Class.Math_Round(status_time_table[4], status_time_table[0], 2) * 100;
                                Status_Rate.Add("Dev_Name:" + ls_data[iIndex] + ",DISCONNECT:" + status_rate_day[0] + ",STOP:" + status_rate_day[1] + ",EMERGENCY:" + status_rate_day[2] + ",OPERATE:" + status_rate_day[3] + ",SHUTDOWN:0");
                                for (int iIndex_5 = 0; iIndex_5 < status_time_table.Length; iIndex_5++)
                                    status_time_table[iIndex_5] = 0;
                            }

                        }
                        else
                        {
                            double work_time_now = DataTableUtils.toDouble(Status_Value[iIndex_1].Split(':')[1].Split(',')[0]);
                            double oper_time_now = DataTableUtils.toDouble(Status_Value[iIndex_1].Split(':')[1].Split(',')[4]);
                            oper_date = Status_Value[iIndex_1].Split(':')[0].Substring(6, 2) + "號";

                            status_rate_day[3] = cNC_Class.Math_Round(oper_time_now, work_time_now, 2) * 100;//operate_time
                            if (double.IsNaN(status_rate_day[3])) status_rate_day[3] = 0;//避免=非數值



                            data_sec += "{ label:'" + oper_date + "' , y:" + status_rate_day[3] + " },";  //畫表(單獨線)


                            if (iIndex_1 == Status_Value.Count - 1)
                            {
                                ls_data[iIndex] = CNCUtils.MachName_translation(ls_data[iIndex]);

                                OperRate_Str += "{type: 'line',showInLegend: true,name: '" + ls_data[iIndex] + "',indexLabel: '{y}',dataPoints: [" + data_sec + "]},\n";//畫折線
                                //算 Table    
                                status_rate_day[0] = cNC_Class.Math_Round(status_time_table[1], status_time_table[0], 2) * 100;
                                status_rate_day[1] = cNC_Class.Math_Round(status_time_table[2], status_time_table[0], 2) * 100;
                                status_rate_day[2] = cNC_Class.Math_Round(status_time_table[3], status_time_table[0], 2) * 100;
                                status_rate_day[3] = cNC_Class.Math_Round(status_time_table[4], status_time_table[0], 2) * 100;
                                Status_Rate.Add("Dev_Name:" + ls_data[iIndex] + ",DISCONNECT:" + status_rate_day[0] + ",STOP:" + status_rate_day[1] + ",EMERGENCY:" + status_rate_day[2] + ",OPERATE:" + status_rate_day[3] + ",SHUTDOWN:0");
                                for (int iIndex_4 = 0; iIndex_4 < status_time_table.Length; iIndex_4++)
                                    status_time_table[iIndex_4] = 0;
                                //算 Table 
                            }
                        }
                    }
                }
            }
            Status_Table(Status_Rate);  //表格資料
            status_rate[0] = cNC_Class.Math_Round(status_time[1], status_time[0], 2) * 100;
            status_rate[1] = cNC_Class.Math_Round(status_time[2], status_time[0], 2) * 100;
            status_rate[2] = cNC_Class.Math_Round(status_time[3], status_time[0], 2) * 100;
            status_rate[3] = cNC_Class.Math_Round(status_time[4], status_time[0], 2) * 100;
            StatusRate_Str = "Device Name: ,DISCONNECT:" + status_rate[0] + ",STOP:" + status_rate[1] + ",EMERGENCY:" + status_rate[2] + ",OPERATE:" + status_rate[3] + ",SHUTDOWN:0";//圓餅圖
            string date_s = Support.DB.DtUtils.toString(FirstDay).Replace('-', '/');
            string date_e = Support.DB.DtUtils.toString(LastDay).Replace('-', '/');
            timerange = DateTime.Parse(date_s).ToString("yyyy/MM/dd") + " ~ " + DateTime.Parse(date_e).ToString("yyyy/MM/dd");
        }
        private void Status_Table(List<string> Status_Rate)//表格資料
        {
            StatusInfo_th = "<th>設備名稱</th>\n<th>運轉(%)</th>\n<th>待機(%)</th>\n<th>警報(%)</th>\n<th>離線(%)</th>\n";
            string devicename = "";
            foreach (string Status_List in Status_Rate)
            {
                if (Status_List != "--")
                {
                    devicename = CNCUtils.MachName_translation(Status_List.Split(',')[0].Split(':')[1]);
                    StatusInfo_tr += "<tr>";
                    StatusInfo_tr += "<td>" + devicename + "</td>";//devname
                    StatusInfo_tr += "<td>" + Status_List.Split(',')[4].Split(':')[1] + "</td>";//operate
                    StatusInfo_tr += "<td>" + Status_List.Split(',')[2].Split(':')[1] + "</td>";//stop
                    StatusInfo_tr += "<td>" + Status_List.Split(',')[3].Split(':')[1] + "</td>";//emergency
                    StatusInfo_tr += "<td>" + Status_List.Split(',')[1].Split(':')[1] + "</td>";//disconnect
                    StatusInfo_tr += "</tr>";
                }
            }
        }
        private void Get_MachType_List()//取type list
        {
            DropDownList_MachType.Items.Clear();
            dt_data = DataTableUtils.GetDataTable("select type_name from mach_type");
            if (HtmlUtil.Check_DataTable(dt_data))
            {
                DropDownList_MachType.Items.Add("--Select--");

                //string acc_power = HtmlUtil.Search_acc_Column(acc, "Belong_Factory");
                //if (acc_power == "" || acc_power == "All" || acc_power == "全部")
                //{
                for (int iIndex = 0; iIndex < dt_data.Rows.Count; iIndex++)
                    DropDownList_MachType.Items.Add(dt_data.Rows[iIndex]["type_name"].ToString());
                //}
                //else
                //    DropDownList_MachType.Items.Add(acc_power);
            }
        }
        public string get_MachList_html(string dev_name)
        {
            string html_ = "'<div class=\"col-md-12 col-sm-12 col-xs-12\"><div id = \"" + dev_name + "\" class=\"mach_list_Pei\"></div></div>';";//-23
            return js_ += "document.getElementById('mach_list').innerHTML += " + html_ + "";
        }
        public void get_javascrtpt_pie(string dev_status)
        {
            devName = dev_status.Split(':')[1].Split(',')[0];    //MTLINKi設備命名限制如宣告命名方式
            js += "var " + devName + "_ch" + " = new CanvasJS.Chart(\"" + devName + "\", {" +
           "animationEnabled: true," +
           "title:{text: \"" + "狀態比例統計" + "\" ,   fontFamily: 'NotoSans',fontWeight: 'bolder',textAlign: \"center\",     fontSize: 37,}," +
           "subtitles: [{text: '" + timerange + "',fontFamily: 'NotoSans',fontWeight: 'bolder',textAlign: \"center\",fontSize: 15,}]," +
           "legend:{cursor: \"pointer\"}," +
           "data: [{type: \"pie\",toolTipContent: \"{name}: <strong>{y}%</strong>\",indexLabel: \"{name} - {y}%\",dataPoints: [" + get_dataponts(dev_status) + "]}]" +
           "}); " + devName + "_ch.render();";

        }
        private string get_dataponts(string dev_status)
        {
            Chart_Percent = "";
            for (int iIndex = 1; iIndex < dev_status.Split(',').Length - 1; iIndex++)
            {
                string dev_status_title = dev_status.Split(',')[iIndex].Split(':')[0];
                if (dev_status_title == "SHUTDOWN") dev_status_title = "NONE";//關機先用none取代
                string dev_value = dev_status.Split(',')[iIndex].Split(':')[1];
                Chart_Percent += "{ y:" + dev_value + " , name: \"" + cNC_Class.mach_status_EN2CH(dev_status_title) + "\",color: '" + cNC_Class.mach_status_Color(dev_status_title) + "' },";
            }
            return Chart_Percent;
        }
        //event      
        protected void Select_MachGroupClick(object sender, EventArgs e)    //執行運算
        {
            if (DropDownList_MachType.SelectedItem.Text != "--Select--")// && DropDownList_MachGroup.SelectedItem.Text != "--Select--")
            {
                //    Label1.Text = "button";
                b_Page_Load = false;
                string sqlcmd = "";
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                sqlcmd = "select * from mach_type where type_name = '" + DropDownList_MachType.SelectedItem.Text + "' ";
                //if (DropDownList_MachGroup.SelectedItem.Text != "--Select--")
                //    sqlcmd = sqlcmd + " and group_name like '%" + DropDownList_MachGroup.SelectedItem.Text + "%' ";
                DataTable dt = DataTableUtils.GetDataTable(sqlcmd);

                if (HtmlUtil.Check_DataTable(dt))
                {
                    if (DropDownList_MachGroup.SelectedItem.Text == "--Select--")
                    {
                        string Group = DataTableUtils.toString(dt.Rows[0]["group_name"]);
                        if (Group != "")
                        {
                            string[] Machine_Group = Group.Split(',');
                            for (int i = 0; i < Machine_Group.Length; i++)
                                Read_Data(DataTableUtils.toString(Machine_Group[i]));
                        }
                        else
                            Read_Data("不存在");

                    }
                    else
                        Read_Data(DropDownList_MachGroup.SelectedItem.Text);
                }
            }
            else
                Response.Redirect("Analysis_oper_rate.aspx");
        }
        protected void button_select_Click(object sender, EventArgs e)  //時間篩選
        {

            string button_id = DataTableUtils.toString(((Control)sender).ID.Split('_')[1]);


            List<string> ST_First_Last_Time = cNC_Class.get_search_time(DataTableUtils.toString(((Control)sender).ID.Split('_')[1]), "", "");
            FirstDay = DateTime.ParseExact(ST_First_Last_Time[0].Split(',')[0], "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture);
            LastDay = DateTime.ParseExact(ST_First_Last_Time[0].Split(',')[1], "yyyyMMddHHmmss", System.Globalization.CultureInfo.CurrentCulture);

            textbox_st.Text = FirstDay.ToString("yyyy-MM-dd");
            textbox_ed.Text = LastDay.ToString("yyyy-MM-dd");

            if (LastDay > DateTime.Now) LastDay = DateTime.Now;
            Type = ST_First_Last_Time[1];




            //if (DropDownList_MachType.SelectedItem.Text != "--Select--")// && DropDownList_MachGroup.SelectedItem.Text != "--Select--")
            //{
            //    b_Page_Load = false;
            //    string sqlcmd = "";
            //    GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
            //    sqlcmd = "select * from mach_type where type_name = '" + DropDownList_MachType.SelectedItem.Text + "' ";
            //    //if (DropDownList_MachGroup.SelectedItem.Text != "--Select--")
            //    //    sqlcmd = sqlcmd + " and group_name like '%" + DropDownList_MachGroup.SelectedItem.Text + "%' ";
            //    DataTable dt = DataTableUtils.GetDataTable(sqlcmd);
            //    if (dt.Rows.Count > 0)
            //    {
            //        if (DropDownList_MachGroup.SelectedItem.Text == "--Select--")
            //        {
            //            string Group = DataTableUtils.toString(dt.Rows[0]["group_name"]);
            //            if (Group != "")
            //            {
            //                string[] Machine_Group = Group.Split(',');
            //                for (int i = 0; i < Machine_Group.Length; i++)
            //                    Read_Data(DataTableUtils.toString(Machine_Group[i]), Type);
            //            }
            //            else
            //                Read_Data("不存在");

            //        }
            //        else
            //            Read_Data(DropDownList_MachGroup.SelectedItem.Text, Type);
            //    }
            //}
            //else
            //    Read_Data("", Type);

        }
        protected void DropDownList_MachType_SelectedIndexChanged(object sender, EventArgs e)//cbx select事件//取group list
        {
            if (DropDownList_MachType.SelectedItem.Text != "--Select--")
            {
                GlobalVar.UseDB_setConnString(myclass.GetConnByDekVisCnc_inside);
                ls_data.Clear();
                DropDownList_MachGroup.Items.Clear();
                ls_data = DataTableUtils.GetDataTable("select group_name from mach_type where type_name = '" + DropDownList_MachType.SelectedItem.Text + "'").Rows[0].ItemArray[0].ToString().Split(',').ToList();
                DropDownList_MachGroup.Items.Add("--Select--");
                for (int iIndex = 0; iIndex < ls_data.Count; iIndex++)
                    DropDownList_MachGroup.Items.Add(ls_data[iIndex]);
            }
            else
            {
                DropDownList_MachGroup.Items.Clear();
                DropDownList_MachGroup.Items.Add(" ");
            }
        }
    }
}